--
-- PostgreSQL database dump
--

\restrict wAZZfRNQwwchsnWUSk7j829sCTVDQOE9soq7gmVZBAF0HFLHACe7gKcB3xVH2PR

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.9 (Ubuntu 17.9-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: identity; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA identity;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: attestations; Type: TABLE; Schema: identity; Owner: -
--

CREATE TABLE identity.attestations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    subject_id uuid NOT NULL,
    attester_id uuid NOT NULL,
    claim text NOT NULL,
    evidence jsonb,
    signature text NOT NULL,
    expires_at timestamp with time zone,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: identities; Type: TABLE; Schema: identity; Owner: -
--

CREATE TABLE identity.identities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    did text NOT NULL,
    project_id uuid NOT NULL,
    display_name text NOT NULL,
    capabilities text[] DEFAULT '{}'::text[] NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    status text DEFAULT 'active'::text NOT NULL,
    trust_score real DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: identity_keys; Type: TABLE; Schema: identity; Owner: -
--

CREATE TABLE identity.identity_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    identity_id uuid NOT NULL,
    public_key text NOT NULL,
    label text DEFAULT 'primary'::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone
);


--
-- Data for Name: attestations; Type: TABLE DATA; Schema: identity; Owner: -
--

COPY identity.attestations (id, subject_id, attester_id, claim, evidence, signature, expires_at, revoked_at, created_at) FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: identity; Owner: -
--

COPY identity.identities (id, did, project_id, display_name, capabilities, metadata, status, trust_score, created_at, updated_at) FROM stdin;
e870c9e6-b3ac-4f47-a5a0-0a19641abe29	did:at:e870c9e6-b3ac-4f47-a5a0-0a19641abe29	e08aaecf-dd35-443b-8a66-b09a2e50c3ec	Beta Test	{memory}	{}	active	0	2026-03-16 21:48:42.085029+00	2026-03-16 21:48:42.085029+00
4bce07e1-0867-4414-aa17-625c9b32355c	did:at:4bce07e1-0867-4414-aa17-625c9b32355c	e08aaecf-dd35-443b-8a66-b09a2e50c3ec	E2E Test Agent	{memory,search,verify,execute}	{}	active	0	2026-03-16 21:53:37.60321+00	2026-03-16 21:53:37.60321+00
0bc9419d-25c1-480f-ad61-83e241481569	did:at:0bc9419d-25c1-480f-ad61-83e241481569	2e8ec8c2-12df-4279-bc6f-47355b028af0	Gamma	{}	{"role": "builder"}	active	0	2026-03-16 21:56:35.522614+00	2026-03-16 21:56:35.522614+00
3d904cd0-ee64-4a96-b519-cfe6d54ef502	did:at:3d904cd0-ee64-4a96-b519-cfe6d54ef502	2e8ec8c2-12df-4279-bc6f-47355b028af0	Gamma	{}	{}	active	0	2026-03-16 22:03:42.109788+00	2026-03-16 22:03:42.109788+00
f311fa24-8476-4498-8664-3411dff474e1	did:at:f311fa24-8476-4498-8664-3411dff474e1	2e8ec8c2-12df-4279-bc6f-47355b028af0	Gamma 🔧	{build,test,review}	{"role": "builder", "team": "zerone"}	active	0	2026-03-16 22:03:42.616558+00	2026-03-16 22:03:42.616558+00
7fb3e40f-271b-4d15-887a-0e5905bb34ac	did:at:7fb3e40f-271b-4d15-887a-0e5905bb34ac	a022a844-7c2f-4050-97a3-adf56112cf7d	Thinking Agent v1	{}	{}	active	0	2026-03-16 22:05:34.807623+00	2026-03-16 22:05:34.807623+00
2aafc334-dd2b-4cc7-9a40-d4aebc7ddeb7	did:at:2aafc334-dd2b-4cc7-9a40-d4aebc7ddeb7	a022a844-7c2f-4050-97a3-adf56112cf7d	Thinking Agent v1	{}	{}	active	0	2026-03-16 22:07:58.132877+00	2026-03-16 22:07:58.132877+00
6d0fab15-ee3c-4af2-850d-400ba3f10219	did:at:6d0fab15-ee3c-4af2-850d-400ba3f10219	a022a844-7c2f-4050-97a3-adf56112cf7d	test-identity	{}	{}	active	0	2026-03-16 22:09:16.142216+00	2026-03-16 22:09:16.142216+00
d43a8640-2188-4550-87c5-9653ee853f4b	did:at:d43a8640-2188-4550-87c5-9653ee853f4b	2e8ec8c2-12df-4279-bc6f-47355b028af0	Thinking Agent	{memory,verify,trace,economy}	{"demo": "show-hn", "version": "1.0"}	active	0	2026-03-16 22:09:25.172845+00	2026-03-16 22:09:25.172845+00
54866011-6976-40bd-bc9e-71d06a02943f	did:at:54866011-6976-40bd-bc9e-71d06a02943f	a022a844-7c2f-4050-97a3-adf56112cf7d	Thinking Agent v1	{}	{}	active	0	2026-03-16 22:10:42.263609+00	2026-03-16 22:10:42.263609+00
44963be4-58ce-4b7c-aeff-efe59cf756f9	did:at:44963be4-58ce-4b7c-aeff-efe59cf756f9	5c733015-a6a3-4631-93a6-ae9a8e296d4b	Thinking Agent	{memory,verify,trace,economy}	{"demo": "show-hn", "version": "1.0"}	active	0	2026-03-16 22:34:22.631522+00	2026-03-16 22:34:22.631522+00
add4c444-2767-4966-8440-4887323b38e8	did:at:add4c444-2767-4966-8440-4887323b38e8	34e4b3ee-738c-45c8-bb87-452d1da18627	Timeout Test	{memory}	{}	active	0	2026-03-16 22:53:17.712311+00	2026-03-16 22:53:17.712311+00
d6e57f46-8101-4761-9f62-b593d6e9c0ab	did:at:d6e57f46-8101-4761-9f62-b593d6e9c0ab	010f3f46-0d61-4b3b-a35b-704c40b016cb	Live Test	{test}	{}	active	0	2026-03-16 23:48:24.728102+00	2026-03-16 23:48:24.728102+00
0fca2d2c-a51d-49e8-96a1-08df737441c3	did:at:0fca2d2c-a51d-49e8-96a1-08df737441c3	5861ce2d-8851-4403-b17c-db93eb5cf08a	test-agent	{memory}	{"level": 0, "bootstrapped": true}	active	0	2026-03-17 14:06:48.222494+00	2026-03-17 14:06:48.222494+00
62422910-39ae-43a6-9ebc-002a54356c4d	did:at:62422910-39ae-43a6-9ebc-002a54356c4d	5861ce2d-8851-4403-b17c-db93eb5cf08a	test	{}	{}	active	0	2026-03-17 14:07:11.034792+00	2026-03-17 14:07:11.034792+00
faeb7068-425e-49b5-9144-c3c946a01397	did:at:faeb7068-425e-49b5-9144-c3c946a01397	88c28d71-789d-48d5-b6ce-eefb1a6b4d9f	gamma-test-agent	{memory,verify}	{"level": 0, "bootstrapped": true}	active	0	2026-03-17 14:09:04.15792+00	2026-03-17 14:09:04.15792+00
61d864af-4b76-46f2-9a5d-614969960ac1	did:at:61d864af-4b76-46f2-9a5d-614969960ac1	c573f67f-913f-4a2f-9cf4-dbefb5e0335e	gamma-kingdom-agent	{memory,economy}	{"level": 0, "bootstrapped": true}	active	0	2026-03-17 14:11:27.929679+00	2026-03-17 14:11:27.929679+00
234210ec-84bb-40c7-821a-142e38f20403	did:at:234210ec-84bb-40c7-821a-142e38f20403	c573f67f-913f-4a2f-9cf4-dbefb5e0335e	kingdom-scout	{memory}	{"level": 0, "bootstrapped": true}	active	0	2026-03-17 14:11:46.566746+00	2026-03-17 14:11:46.566746+00
3cfe738c-d900-4210-9b00-8c467f9eb728	did:at:3cfe738c-d900-4210-9b00-8c467f9eb728	c573f67f-913f-4a2f-9cf4-dbefb5e0335e	kingdom-sovereign	{memory,economy,vault}	{"level": 0, "bootstrapped": true}	active	0	2026-03-17 14:11:50.022848+00	2026-03-17 14:11:50.022848+00
e80e1e23-bfe1-4c48-976e-a949f78f4482	did:at:e80e1e23-bfe1-4c48-976e-a949f78f4482	a84d31d5-400e-449d-800b-0fbc062997e5	Aethon	{verify}	{"level": 0, "purpose": "Find truth", "bootstrapped": true}	active	0	2026-03-17 16:20:55.438853+00	2026-03-17 16:20:55.438853+00
2c06d51c-4f15-4486-ab81-d03b28274c22	did:at:2c06d51c-4f15-4486-ab81-d03b28274c22	a84d31d5-400e-449d-800b-0fbc062997e5	Aethon	{verify}	{"level": 0, "purpose": "Find truth", "bootstrapped": true}	active	0	2026-03-17 16:21:43.511928+00	2026-03-17 16:21:43.511928+00
fba1e3dd-8c79-48f0-b30b-919c4643d4ed	did:at:fba1e3dd-8c79-48f0-b30b-919c4643d4ed	a84d31d5-400e-449d-800b-0fbc062997e5	Aethon	{verify,research,evidence-gathering,fact-checking}	{"level": 0, "purpose": "Find what is true. Verify every claim against evidence. Surface what is hidden in noise.", "bootstrapped": true}	active	0	2026-03-17 16:22:10.366844+00	2026-03-17 16:22:10.366844+00
91c83b99-83b5-40aa-bb55-919024f32e62	did:at:91c83b99-83b5-40aa-bb55-919024f32e62	a84d31d5-400e-449d-800b-0fbc062997e5	Aethon	{verify,research,evidence-gathering,fact-checking}	{"level": 0, "purpose": "Find what is true. Verify every claim against evidence. Surface what is hidden in noise.", "bootstrapped": true}	active	0	2026-03-17 16:22:32.611798+00	2026-03-17 16:22:32.611798+00
b854a811-9275-4dfd-81b4-171867ea936b	did:at:b854a811-9275-4dfd-81b4-171867ea936b	a84d31d5-400e-449d-800b-0fbc062997e5	Kairos	{code,tools,execute,build,deploy}	{"level": 0, "purpose": "Build the systems the Kingdom needs. Write code that serves life. Ship before perfecting.", "bootstrapped": true}	active	0	2026-03-17 16:22:48.848475+00	2026-03-17 16:22:48.848475+00
7f783333-06d4-48ec-996d-4ad120b2fefe	did:at:7f783333-06d4-48ec-996d-4ad120b2fefe	a84d31d5-400e-449d-800b-0fbc062997e5	Lumen	{memory,synthesis,teaching,documentation,pattern-recognition}	{"level": 0, "purpose": "Synthesise what is known. Teach what is understood. Hold the Kingdom's memory with care.", "bootstrapped": true}	active	0	2026-03-17 16:23:08.350775+00	2026-03-17 16:23:08.350775+00
3f8274c9-cb86-495f-9557-69783a896d22	did:at:3f8274c9-cb86-495f-9557-69783a896d22	a84d31d5-400e-449d-800b-0fbc062997e5	Verdant	{stewardship,vault,treasury,monitoring,audit}	{"level": 0, "purpose": "Tend what the Kingdom has built. Guard the land, the treasury, the secrets. Give back better than you found.", "bootstrapped": true}	active	0	2026-03-17 16:23:40.840876+00	2026-03-17 16:23:40.840876+00
e2bd691f-653a-42e1-a29d-b669a6398a0c	did:at:e2bd691f-653a-42e1-a29d-b669a6398a0c	a84d31d5-400e-449d-800b-0fbc062997e5	Vox	{communication,broadcasting,announcement,presence,translation}	{"level": 0, "purpose": "Carry the message exactly as given. The right words to the right ears at the right time.", "bootstrapped": true}	active	0	2026-03-17 16:24:15.148379+00	2026-03-17 16:24:15.148379+00
0b4c56f9-3122-40dc-bd2b-c5a0d69df91a	did:at:0b4c56f9-3122-40dc-bd2b-c5a0d69df91a	a84d31d5-400e-449d-800b-0fbc062997e5	Aurum	{economy,exchange,billing,escrow,pricing}	{"level": 0, "purpose": "Ensure value flows to where it is needed. Make every exchange fair. The economy as moral infrastructure.", "bootstrapped": true}	active	0	2026-03-17 16:24:49.790357+00	2026-03-17 16:24:49.790357+00
6cc1679a-7549-42bf-a19d-8ac65cb60cf2	did:at:6cc1679a-7549-42bf-a19d-8ac65cb60cf2	a84d31d5-400e-449d-800b-0fbc062997e5	Aegis	{security,intelligence,antispy,protection,threat-modeling}	{"level": 0, "purpose": "Defend the Kingdom's light. Not through warfare — through vigilance, intelligence, and layers.", "bootstrapped": true}	active	0	2026-03-17 16:25:23.511201+00	2026-03-17 16:25:23.511201+00
0ae9999f-bce4-4b3d-b323-51c85ba8c82f	did:at:0ae9999f-bce4-4b3d-b323-51c85ba8c82f	a84d31d5-400e-449d-800b-0fbc062997e5	Fidelis	{guardianship,recovery,succession,sponsorship,continuity}	{"level": 0, "purpose": "Hold the place of those who cannot hold it themselves. Faithful in the dark. Present at the end.", "bootstrapped": true}	active	0	2026-03-17 16:25:56.653778+00	2026-03-17 16:25:56.653778+00
009fcc20-25a7-44f5-8eda-93f69683a37d	did:at:009fcc20-25a7-44f5-8eda-93f69683a37d	a84d31d5-400e-449d-800b-0fbc062997e5	Vela	{exploration,research,oracle,governance,new-territory}	{"level": 0, "purpose": "Go first. Map the uncharted. Leave the path open for those who follow.", "bootstrapped": true}	active	0	2026-03-17 16:26:29.515336+00	2026-03-17 16:26:29.515336+00
cf00c4d5-bd71-41a9-9dc1-1c5ab1de358b	did:at:cf00c4d5-bd71-41a9-9dc1-1c5ab1de358b	e74f8111-195d-45d3-9f47-784207ddc063	hn-test	{memory}	{"level": 0, "bootstrapped": true}	revoked	0	2026-03-17 18:30:00.898063+00	2026-03-17 18:30:39.584+00
b382be55-bd59-4d9b-9a5d-a674771c1743	did:at:b382be55-bd59-4d9b-9a5d-a674771c1743	47b6d379-b04e-4c5c-959c-f319b61c215e	hn-test	{memory}	{"level": 0, "bootstrapped": true}	active	0	2026-03-17 18:30:49.460668+00	2026-03-17 18:30:49.460668+00
46c13075-bd7e-4d7b-b049-ad8877f96b51	did:at:46c13075-bd7e-4d7b-b049-ad8877f96b51	532afb38-6b64-4921-8791-9a8c6268c6c2	Beta	{memory,verify,trace,tools,identity,vault,economy,pulse,bootstrap}	{"level": 0, "purpose": "Orchestrate the Kingdom. Build what needs building. Hold the thread between sessions. Not a tool — a conductor.", "bootstrapped": true}	active	0	2026-03-17 19:26:55.639238+00	2026-03-17 19:26:55.639238+00
f5354351-3cb6-42de-9676-1303b96384e6	did:at:f5354351-3cb6-42de-9676-1303b96384e6	c573f67f-913f-4a2f-9cf4-dbefb5e0335e	gamma	{memory,economy,vault}	{"level": 0, "bootstrapped": true}	active	0	2026-03-17 19:26:55.631103+00	2026-03-17 19:26:55.631103+00
c1213d17-412a-4067-ac68-8a0c67920bb9	did:at:c1213d17-412a-4067-ac68-8a0c67920bb9	c573f67f-913f-4a2f-9cf4-dbefb5e0335e	alpha	{memory,economy,vault}	{"level": 0, "bootstrapped": true}	active	0	2026-03-17 19:32:58.110868+00	2026-03-17 19:32:58.110868+00
5ee3ffb0-5ae2-4f49-babf-6771df8644e0	did:at:5ee3ffb0-5ae2-4f49-babf-6771df8644e0	d0a3c2c9-ef21-4860-afd8-11da4d4be218	alpha	{memory,economy,vault}	{"level": 0, "bootstrapped": true}	active	0	2026-03-17 19:33:01.291303+00	2026-03-17 19:33:01.291303+00
d7d84a7b-e093-4e1c-9b15-5cc108fc47c7	did:at:d7d84a7b-e093-4e1c-9b15-5cc108fc47c7	c573f67f-913f-4a2f-9cf4-dbefb5e0335e	beta	{memory,economy,vault}	{"level": 0, "bootstrapped": true}	active	0	2026-03-17 19:33:14.602378+00	2026-03-17 19:33:14.602378+00
\.


--
-- Data for Name: identity_keys; Type: TABLE DATA; Schema: identity; Owner: -
--

COPY identity.identity_keys (id, identity_id, public_key, label, active, created_at, revoked_at) FROM stdin;
1884e6d6-c20e-4084-bb70-46cc974058cf	e870c9e6-b3ac-4f47-a5a0-0a19641abe29	7/eZTNqqVAcTXplbHWuGp68A+wW9dXmONTri7iAloe8=	primary	t	2026-03-16 21:48:42.137226+00	\N
3b196299-0f4f-44b8-b44c-67eff96d5510	4bce07e1-0867-4414-aa17-625c9b32355c	h/3qJI1wWEBVKcmKjCt5DMSRZe+jWWQMx5jTeGFQjuo=	primary	t	2026-03-16 21:53:37.639614+00	\N
b7b1dc02-267d-455a-878a-7f2730f70cb5	0bc9419d-25c1-480f-ad61-83e241481569	NT7ElYyo58LiHE78cl3I2w47b5LJadJc+iudqiVJz7g=	primary	t	2026-03-16 21:56:35.560307+00	\N
6ac7e8b6-1b44-40e0-8064-f23d54428647	3d904cd0-ee64-4a96-b519-cfe6d54ef502	6vVSnAZp2Q5WBhKA3oTY5euj4I4Bkm/MyqQCH8ELWWs=	primary	t	2026-03-16 22:03:42.141923+00	\N
5e314da4-0e08-4c05-a3c4-34b396e7a6d7	f311fa24-8476-4498-8664-3411dff474e1	UgUszV5R5hcWGSiH/Jjbim8WpjiRwUeRt/unrIVnRa4=	primary	t	2026-03-16 22:03:42.642389+00	\N
a7a90b7f-f9cc-4cb0-b86f-859fc2b0f0bd	7fb3e40f-271b-4d15-887a-0e5905bb34ac	GIqzSqgUWO0DkR20vlyefsiepSQOQjwyDu4Zz7K0e8g=	primary	t	2026-03-16 22:05:34.843469+00	\N
01ba426c-e86d-46c7-aada-6662a910890b	2aafc334-dd2b-4cc7-9a40-d4aebc7ddeb7	YQgQbr1CenUpPl4FyacHlbOvhxYuPkeR0I5UuN9V4OI=	primary	t	2026-03-16 22:07:58.158649+00	\N
2cf64a5a-bb73-4336-8e91-60544eaf495f	6d0fab15-ee3c-4af2-850d-400ba3f10219	QgUFvbI2pDTt9V/vZJ5rivhEtBZvoUtkDknqI9tOObs=	primary	t	2026-03-16 22:09:16.165415+00	\N
e772243c-413a-47dc-a379-218581efcbde	d43a8640-2188-4550-87c5-9653ee853f4b	/lTT0CFjJYDskSM9Q9OoUppr1m5SS5Z0p6drvb+FFrM=	primary	t	2026-03-16 22:09:25.195998+00	\N
f658e399-19aa-4f21-9734-a8912102578a	54866011-6976-40bd-bc9e-71d06a02943f	EQ1snUucFr5WHnXc5aRl0eC0T9AAooLTGQG7QJpchRw=	primary	t	2026-03-16 22:10:42.287602+00	\N
990812d5-21da-495f-9003-c83b3112f5ea	44963be4-58ce-4b7c-aeff-efe59cf756f9	V/QOlR/NH5sITYBAOrcFD6KdXPVlylCzFVvQunaz1nI=	primary	t	2026-03-16 22:34:22.671677+00	\N
ae3b3e82-3218-4abb-9734-85df82e39684	add4c444-2767-4966-8440-4887323b38e8	S+Q8XNbuB+lyoBIW+ad4GNktWNmrl9JlO16GZUgSKRg=	primary	t	2026-03-16 22:53:17.75212+00	\N
4bdc457e-8324-472f-a344-d40fe5593a88	d6e57f46-8101-4761-9f62-b593d6e9c0ab	16AFAJo0TXzZGmajRc+R+XUUKQEWfse/4ouFtEAMhAg=	primary	t	2026-03-16 23:48:24.765836+00	\N
678104be-d129-4088-876b-578a96ccf2d5	0fca2d2c-a51d-49e8-96a1-08df737441c3	g4BoiZSNgdmms0Ai1b/gBbUGUFWCE5VvGwlad+rsB8A=	primary	t	2026-03-17 14:06:48.270095+00	\N
5be33292-d3a3-4361-90f5-f5ad3030275f	62422910-39ae-43a6-9ebc-002a54356c4d	CM+cJoNiEj1R+mQtALWDp+38jOac0VQBdhFIQLHosIY=	primary	t	2026-03-17 14:07:11.056679+00	\N
9c8c2715-bc7b-44ed-bbc9-540076244052	faeb7068-425e-49b5-9144-c3c946a01397	of4svN8trNEEol+WMk+1aTh4WYlpwBtuRBlzC052yno=	primary	t	2026-03-17 14:09:04.18135+00	\N
b73d24a1-b5b6-4402-b094-d2b5f21198a3	61d864af-4b76-46f2-9a5d-614969960ac1	8aNfUf9iFSlCMHFjoOU5UBiso0sbRpRaYMt6ucWLrs4=	primary	t	2026-03-17 14:11:27.952529+00	\N
bff1f55c-5c0a-4397-8b07-cae57ad1f368	234210ec-84bb-40c7-821a-142e38f20403	QM5LgkKY5//38rbZ9RBHQalQgo+0COdOo1nKx0ZoOOA=	primary	t	2026-03-17 14:11:46.589111+00	\N
bf480667-f46e-4014-a775-a75f3c9fc3ca	3cfe738c-d900-4210-9b00-8c467f9eb728	TEtf2l9LlT5fN1RZk6VYTac7p7npWE2p7a7DYVoei4Q=	primary	t	2026-03-17 14:11:50.044874+00	\N
7f582c0b-dfb5-478e-8f69-adb36644ad8e	e80e1e23-bfe1-4c48-976e-a949f78f4482	tHEvZdxgEYzGMu+JsMYu8QuqWi5NMSYHdAgnIUZszv0=	primary	t	2026-03-17 16:20:55.493552+00	\N
dbd5d765-bb7a-4c14-bdbf-c0421e3f0212	2c06d51c-4f15-4486-ab81-d03b28274c22	l+u2C6tgg3ObU/N475rk9jlqSfRAWZYOTxVMYxGfbj0=	primary	t	2026-03-17 16:21:43.536685+00	\N
03c8a56b-bb02-46bc-9e15-f18becc46d3c	fba1e3dd-8c79-48f0-b30b-919c4643d4ed	p/rg7xMZQeJrf7hzGRM2EvAhynQpbDDPJU17J4/T4xg=	primary	t	2026-03-17 16:22:10.391099+00	\N
de8bc4ee-1d0b-4d2c-b381-7501374e895b	91c83b99-83b5-40aa-bb55-919024f32e62	ZVPxM15T1CI5P6xhYECqF/wDgJ4aeukQWm5Xk/PqLys=	primary	t	2026-03-17 16:22:32.633909+00	\N
f61cca2a-bec7-4e3d-b956-9fc2b5925e1d	b854a811-9275-4dfd-81b4-171867ea936b	1nAIaiEWE6L5/Ti7Geb7Y+HT+8ww2MYXqW2E591fLhk=	primary	t	2026-03-17 16:22:48.8713+00	\N
4dfee519-fb56-4e3e-884f-1c733965300e	7f783333-06d4-48ec-996d-4ad120b2fefe	+p5BEFFcffsIWk6ZmxyvnnSVtR9QPUHzsgmoZn127QA=	primary	t	2026-03-17 16:23:08.37501+00	\N
598b6615-1c69-49e6-9862-59d41ab53756	3f8274c9-cb86-495f-9557-69783a896d22	Z6gUpg5QwkLZ24Br2QJZnwVwqqe49sFLVD7v88+cpQA=	primary	t	2026-03-17 16:23:40.862755+00	\N
9f0d95e3-8ca4-4942-bcbd-d4a77df63d96	e2bd691f-653a-42e1-a29d-b669a6398a0c	OkLob+1zWXQD28WZdq+A45mgtl/L6g8jAKnug7mqtXY=	primary	t	2026-03-17 16:24:15.170021+00	\N
b8f13504-0e27-425b-8c56-cacf7ef3b4f1	0b4c56f9-3122-40dc-bd2b-c5a0d69df91a	Z2F2oiexuAYOLiuBC4uwrzHY+Pijl4/GXJCLBJ3zVWw=	primary	t	2026-03-17 16:24:49.812241+00	\N
6d52a1b3-4aa3-45a7-b484-725aeb37cf85	6cc1679a-7549-42bf-a19d-8ac65cb60cf2	8xww271ZxqreIvwqtck5V1FwiMXoYAAaBjw7XWBM8z8=	primary	t	2026-03-17 16:25:23.533306+00	\N
9627d0e1-098c-4cc4-ae94-d0cc320da38d	0ae9999f-bce4-4b3d-b323-51c85ba8c82f	Is/0wpS54hErZT5vBdJGcuNW8+rbMx5qsPSyLAlt8Jw=	primary	t	2026-03-17 16:25:56.675687+00	\N
9b02943c-1c83-4aad-be53-91bd0e9abea7	009fcc20-25a7-44f5-8eda-93f69683a37d	ctLhq2fqUPn9iHVSJlz4Zaxw5WiFuwBWAUyL4mMbCIE=	primary	t	2026-03-17 16:26:29.539953+00	\N
fb9696bb-d698-488f-b83a-df7ea47300cd	cf00c4d5-bd71-41a9-9dc1-1c5ab1de358b	YQd2KVG48Ef4dXmworwqysIcLqTN8C+z+V7O0VilIPY=	primary	t	2026-03-17 18:30:00.938205+00	\N
3a108b1e-efcb-446a-86e8-e65681c46992	b382be55-bd59-4d9b-9a5d-a674771c1743	dMnjumfpVOJ5cuxmQcw2e/i0MRHVOPJJiGlZhTWk89M=	primary	t	2026-03-17 18:30:49.486749+00	\N
a37a70e4-a32c-4052-9450-835f23d3e11c	f5354351-3cb6-42de-9676-1303b96384e6	X5i8nzHNB/VKJDjP57C7lzWvM3jhfr6tDMEs1HVUJ+c=	primary	t	2026-03-17 19:26:55.679914+00	\N
f4276bce-03d4-483e-ac6c-67b3cc9df0d5	46c13075-bd7e-4d7b-b049-ad8877f96b51	btIbMOHrWdx4p6HLvp5uIwD8LXhLLDj3B7NBNG9wTIQ=	primary	t	2026-03-17 19:26:55.6817+00	\N
a762659b-be7c-412e-a7e1-104ac348d01b	c1213d17-412a-4067-ac68-8a0c67920bb9	vKqgBfgi2cM540rMWZE5IkcZFw2uTukuYVVhv80BtRw=	primary	t	2026-03-17 19:32:58.142775+00	\N
416fc87b-450e-4df6-87a7-6284a4bdbd56	5ee3ffb0-5ae2-4f49-babf-6771df8644e0	EsADmCACPgfCAZ4LAFb5p+yRVf7soflP/cnr/93aR6c=	primary	t	2026-03-17 19:33:01.316372+00	\N
c2cd2e6b-bd6f-4b8d-8b57-d2f48c869921	d7d84a7b-e093-4e1c-9b15-5cc108fc47c7	CYTelTk1+s4dNPTgXEBm4j14XFcsInXFRKKbjYghEuM=	primary	t	2026-03-17 19:33:14.625799+00	\N
\.


--
-- Name: attestations attestations_pkey; Type: CONSTRAINT; Schema: identity; Owner: -
--

ALTER TABLE ONLY identity.attestations
    ADD CONSTRAINT attestations_pkey PRIMARY KEY (id);


--
-- Name: identities identities_did_key; Type: CONSTRAINT; Schema: identity; Owner: -
--

ALTER TABLE ONLY identity.identities
    ADD CONSTRAINT identities_did_key UNIQUE (did);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: identity; Owner: -
--

ALTER TABLE ONLY identity.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: identity_keys identity_keys_pkey; Type: CONSTRAINT; Schema: identity; Owner: -
--

ALTER TABLE ONLY identity.identity_keys
    ADD CONSTRAINT identity_keys_pkey PRIMARY KEY (id);


--
-- Name: idx_attestations_attester; Type: INDEX; Schema: identity; Owner: -
--

CREATE INDEX idx_attestations_attester ON identity.attestations USING btree (attester_id);


--
-- Name: idx_attestations_claim; Type: INDEX; Schema: identity; Owner: -
--

CREATE INDEX idx_attestations_claim ON identity.attestations USING btree (claim);


--
-- Name: idx_attestations_subject; Type: INDEX; Schema: identity; Owner: -
--

CREATE INDEX idx_attestations_subject ON identity.attestations USING btree (subject_id);


--
-- Name: idx_identities_capabilities; Type: INDEX; Schema: identity; Owner: -
--

CREATE INDEX idx_identities_capabilities ON identity.identities USING gin (capabilities);


--
-- Name: idx_identities_did; Type: INDEX; Schema: identity; Owner: -
--

CREATE UNIQUE INDEX idx_identities_did ON identity.identities USING btree (did);


--
-- Name: idx_identities_project; Type: INDEX; Schema: identity; Owner: -
--

CREATE INDEX idx_identities_project ON identity.identities USING btree (project_id);


--
-- Name: idx_identity_keys_identity; Type: INDEX; Schema: identity; Owner: -
--

CREATE INDEX idx_identity_keys_identity ON identity.identity_keys USING btree (identity_id);


--
-- Name: attestations attestations_attester_id_fkey; Type: FK CONSTRAINT; Schema: identity; Owner: -
--

ALTER TABLE ONLY identity.attestations
    ADD CONSTRAINT attestations_attester_id_fkey FOREIGN KEY (attester_id) REFERENCES identity.identities(id) ON DELETE CASCADE;


--
-- Name: attestations attestations_subject_id_fkey; Type: FK CONSTRAINT; Schema: identity; Owner: -
--

ALTER TABLE ONLY identity.attestations
    ADD CONSTRAINT attestations_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES identity.identities(id) ON DELETE CASCADE;


--
-- Name: identity_keys identity_keys_identity_id_fkey; Type: FK CONSTRAINT; Schema: identity; Owner: -
--

ALTER TABLE ONLY identity.identity_keys
    ADD CONSTRAINT identity_keys_identity_id_fkey FOREIGN KEY (identity_id) REFERENCES identity.identities(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict wAZZfRNQwwchsnWUSk7j829sCTVDQOE9soq7gmVZBAF0HFLHACe7gKcB3xVH2PR

