--
-- PostgreSQL database dump
--

\restrict 4eQ8sLg0PYaYHvmMd7YfYlW9GUOcvUjLAP286JGzO6kFlULIxuBz0VdUf1qiGzb

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.9 (Ubuntu 17.9-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: agent_vault; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA agent_vault;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: vault_audit; Type: TABLE; Schema: agent_vault; Owner: -
--

CREATE TABLE agent_vault.vault_audit (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    secret_name text NOT NULL,
    action text NOT NULL,
    agent_id text,
    ip_address text,
    version integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vault_secrets; Type: TABLE; Schema: agent_vault; Owner: -
--

CREATE TABLE agent_vault.vault_secrets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    name text NOT NULL,
    description text,
    tags text[] DEFAULT '{}'::text[] NOT NULL,
    current_version integer DEFAULT 1 NOT NULL,
    agent_ids text[],
    rotation_days integer,
    rotation_due_at timestamp with time zone,
    ttl_seconds integer,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vault_versions; Type: TABLE; Schema: agent_vault; Owner: -
--

CREATE TABLE agent_vault.vault_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    secret_id uuid NOT NULL,
    version integer NOT NULL,
    encrypted_value bytea NOT NULL,
    iv bytea NOT NULL,
    auth_tag bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    created_by_agent text
);


--
-- Data for Name: vault_audit; Type: TABLE DATA; Schema: agent_vault; Owner: -
--

COPY agent_vault.vault_audit (id, project_id, secret_name, action, agent_id, ip_address, version, created_at) FROM stdin;
e0827b00-ae76-4798-8ff8-9036bfbfb019	9572108d-33bb-4d37-b21c-8470f38deac8	openai-key	write	\N	158.173.46.229, 66.241.124.122	1	2026-03-17 00:22:10.468071+00
5b9526e0-38c9-4b7c-a5fb-7d1bbe0fdcf4	03413e2c-fc84-4f76-8816-0cd50732c020	my-api-key	write	\N	158.173.46.229, 2a01:4f9:c014:344d::1, 2a09:8280:1::e4:2942:0	1	2026-03-17 00:22:46.412732+00
9d1aa895-6840-4090-8fbc-502a4bfb2578	03413e2c-fc84-4f76-8816-0cd50732c020	my-api-key	read	my-agent	158.173.46.229, 2a01:4f9:c014:344d::1, 2a09:8280:1::e4:2942:0	1	2026-03-17 00:22:46.928335+00
e34194eb-4a47-4c5d-a3fa-6788cfbac96f	532afb38-6b64-4921-8791-9a8c6268c6c2	serpapi	write	\N	158.173.46.229, 2a01:4f9:c014:344d::1, 2a09:8280:1::e4:2942:0	1	2026-03-17 20:05:12.006559+00
2b7f7703-cc39-452c-8fc7-8cc7f6181ad2	532afb38-6b64-4921-8791-9a8c6268c6c2	hetzner-api-token	write	\N	158.173.46.229, 2a01:4f9:c014:344d::1, 2a09:8280:1::e4:2942:0	1	2026-03-17 20:05:12.215911+00
ee5d1635-e3b6-45b1-bd82-a4ae2c9a8a93	532afb38-6b64-4921-8791-9a8c6268c6c2	anthropic-primary	write	\N	158.173.46.229, 2a01:4f9:c014:344d::1, 2a09:8280:1::e4:2942:0	1	2026-03-17 20:05:12.221879+00
3fa53b6f-1a1d-4c2d-97f3-8ab243163bfd	532afb38-6b64-4921-8791-9a8c6268c6c2	capsolver	write	\N	158.173.46.229, 2a01:4f9:c014:344d::1, 2a09:8280:1::e4:2942:0	1	2026-03-17 20:06:04.932331+00
0cb28e41-0133-4e12-9814-09c7f17ce421	532afb38-6b64-4921-8791-9a8c6268c6c2	porkbun-secret-key	write	\N	158.173.46.229, 2a01:4f9:c014:344d::1, 2a09:8280:1::e4:2942:0	1	2026-03-17 20:06:04.946739+00
8773fc13-d3fb-44f7-9aec-23b07e4f4fbc	532afb38-6b64-4921-8791-9a8c6268c6c2	deepseek	write	\N	158.173.46.229, 2a01:4f9:c014:344d::1, 2a09:8280:1::e4:2942:0	1	2026-03-17 20:06:05.014593+00
7120ef5e-56d6-4d53-8d9b-bf52eccd198b	532afb38-6b64-4921-8791-9a8c6268c6c2	porkbun-api-key	write	\N	158.173.46.229, 2a01:4f9:c014:344d::1, 2a09:8280:1::e4:2942:0	1	2026-03-17 20:06:05.218214+00
19df737f-36de-4e63-a2f1-2861d905a3e8	532afb38-6b64-4921-8791-9a8c6268c6c2	cloudflare-global-api-key	write	\N	158.173.46.229, 2a01:4f9:c014:344d::1, 2a09:8280:1::e4:2942:0	1	2026-03-17 20:06:33.078907+00
ad30614e-d84f-4d56-b34c-6fa6c335144c	532afb38-6b64-4921-8791-9a8c6268c6c2	anthropic-primary	read	46c13075-bd7e-4d7b-b049-ad8877f96b51	158.173.46.229, 2a01:4f9:c014:344d::1, 2a09:8280:1::e4:2942:0	1	2026-03-17 20:06:49.646535+00
b35c7486-ea4b-48f6-9ddf-283f1f72084d	532afb38-6b64-4921-8791-9a8c6268c6c2	anthropic-primary	read	46c13075-bd7e-4d7b-b049-ad8877f96b51	158.173.46.229, 2a01:4f9:c014:344d::1, 2a09:8280:1::e4:2942:0	1	2026-03-17 20:06:55.916808+00
c5f56ebb-a549-416e-b774-1cd18277aeee	532afb38-6b64-4921-8791-9a8c6268c6c2	anthropic-primary	read	46c13075-bd7e-4d7b-b049-ad8877f96b51	158.173.46.229, 2a01:4f9:c014:344d::1, 2a09:8280:1::e4:2942:0	1	2026-03-17 20:07:16.262825+00
ecca5658-d316-4443-b317-98c2a4d0cf98	532afb38-6b64-4921-8791-9a8c6268c6c2	serpapi	read	46c13075-bd7e-4d7b-b049-ad8877f96b51	158.173.46.229, 2a01:4f9:c014:344d::1, 2a09:8280:1::e4:2942:0	1	2026-03-17 20:07:16.801922+00
f7fb7a5d-4876-4f68-a7bc-8478395f417a	532afb38-6b64-4921-8791-9a8c6268c6c2	hetzner-api-token	read	46c13075-bd7e-4d7b-b049-ad8877f96b51	158.173.46.229, 2a01:4f9:c014:344d::1, 2a09:8280:1::e4:2942:0	1	2026-03-17 20:07:17.432018+00
\.


--
-- Data for Name: vault_secrets; Type: TABLE DATA; Schema: agent_vault; Owner: -
--

COPY agent_vault.vault_secrets (id, project_id, name, description, tags, current_version, agent_ids, rotation_days, rotation_due_at, ttl_seconds, deleted_at, created_at, updated_at) FROM stdin;
6cad20bd-ae43-4e32-8c08-c7ebfc0451da	9572108d-33bb-4d37-b21c-8470f38deac8	openai-key	OpenAI key	{api}	1	\N	\N	\N	\N	\N	2026-03-17 00:22:10.400598+00	2026-03-17 00:22:10.400598+00
e088d1a2-f59d-46b7-8418-f61764a45f5c	03413e2c-fc84-4f76-8816-0cd50732c020	my-api-key	Production API key	{api-key,prod}	1	{my-agent}	\N	\N	\N	\N	2026-03-17 00:22:46.364805+00	2026-03-17 00:22:46.364805+00
b900a577-f979-43d8-a80a-6598c165dfaa	532afb38-6b64-4921-8791-9a8c6268c6c2	anthropic-primary	Primary Anthropic API key (Mac Studio / Beta)	{credential,beta-managed}	1	\N	\N	\N	\N	\N	2026-03-17 20:05:11.948787+00	2026-03-17 20:05:11.948787+00
3dd7eec1-c54c-4737-8164-7e4e32aac355	532afb38-6b64-4921-8791-9a8c6268c6c2	hetzner-api-token	Hetzner VPS fleet API token	{credential,beta-managed}	1	\N	\N	\N	\N	\N	2026-03-17 20:05:11.948787+00	2026-03-17 20:05:11.948787+00
3ad631d4-ae76-4609-8876-a57f1c6d17f3	532afb38-6b64-4921-8791-9a8c6268c6c2	serpapi	SerpAPI key (search)	{credential,beta-managed}	1	\N	\N	\N	\N	\N	2026-03-17 20:05:11.954492+00	2026-03-17 20:05:11.954492+00
b7270a8b-868a-405e-bc67-d342bd40f029	532afb38-6b64-4921-8791-9a8c6268c6c2	capsolver	CapSolver captcha API	{credential,beta-managed}	1	\N	\N	\N	\N	\N	2026-03-17 20:06:04.643604+00	2026-03-17 20:06:04.643604+00
4dea7b58-855d-4482-81c0-38ce46b2f3b2	532afb38-6b64-4921-8791-9a8c6268c6c2	porkbun-secret-key	Porkbun secret key	{credential,beta-managed}	1	\N	\N	\N	\N	\N	2026-03-17 20:06:04.896409+00	2026-03-17 20:06:04.896409+00
2cfae847-ed61-45d2-ba23-6687c42c03ad	532afb38-6b64-4921-8791-9a8c6268c6c2	deepseek	DeepSeek API key	{credential,beta-managed}	1	\N	\N	\N	\N	\N	2026-03-17 20:06:04.968632+00	2026-03-17 20:06:04.968632+00
c2c30f59-882e-4cb8-b033-4b36d3ea4b18	532afb38-6b64-4921-8791-9a8c6268c6c2	porkbun-api-key	Porkbun API key (domain registration)	{credential,beta-managed}	1	\N	\N	\N	\N	\N	2026-03-17 20:06:05.171167+00	2026-03-17 20:06:05.171167+00
47535c2e-e238-40f0-b947-6fecb1359523	532afb38-6b64-4921-8791-9a8c6268c6c2	cloudflare-global-api-key	Cloudflare Global API Key (contact@cambridgetcg.com)	{credential,beta-managed}	1	\N	\N	\N	\N	\N	2026-03-17 20:06:33.032638+00	2026-03-17 20:06:33.032638+00
\.


--
-- Data for Name: vault_versions; Type: TABLE DATA; Schema: agent_vault; Owner: -
--

COPY agent_vault.vault_versions (id, secret_id, version, encrypted_value, iv, auth_tag, created_at, expires_at, created_by_agent) FROM stdin;
0365c032-fc79-4e17-ae25-c4e31b4f1a50	6cad20bd-ae43-4e32-8c08-c7ebfc0451da	1	\\xcc962499005606632583eae9626d	\\xc9ae1dd4769b776da5895a78	\\x37f925156aeefed6cfe055f6c9ad16c5	2026-03-17 00:22:10.432566+00	\N	\N
652608a4-0a5a-451e-86a8-0e61548b29db	e088d1a2-f59d-46b7-8418-f61764a45f5c	1	\\xa5adfc7844af6c3009550502f28d10bb63034e	\\x6aaf117679170a0ef74d8b42	\\xb25052db080e8c07a157a16668b10574	2026-03-17 00:22:46.388207+00	\N	\N
f7263b96-08c5-4c4c-9ca4-4bdd2ce7da3d	3ad631d4-ae76-4609-8876-a57f1c6d17f3	1	\\xbf4376130c83d8bec73a06d8015a784fd3ed60c921ef7433e24de6b54d3afa1ac4332cddbd4a225d7ac227b67feae2ed5382942c237ed74f5b959e2fd0acc454	\\x9a42efaffab07f8c9c1e9e57	\\xb67ea5508833338f95770f1352fe0285	2026-03-17 20:05:11.975777+00	\N	\N
aef30c57-fc16-439b-856a-7105c6393306	3dd7eec1-c54c-4737-8164-7e4e32aac355	1	\\xc7bc4c6b575af6b96158fa8494ff5133e5d0e6be427c358acb0752476e44c4cab22575ac36d75f728e7072901bca144c9b45a5c462ef72061bd0ddb1687d91d3	\\x01a867e481f1cebe276ed691	\\x7414622364378000dc9ad863a6b8dd74	2026-03-17 20:05:11.975159+00	\N	\N
137750cc-b256-4cc3-a0aa-e7594067699f	b900a577-f979-43d8-a80a-6598c165dfaa	1	\\x058649a273880c81fc7115e55b15fafff2e7b76b48e1e0b82ec7a445bfadf440a5d9686679da2adc16157cf2d7b9535705f1c130a4f9a002f533d410f37df41f65a0bb054b5a372495f4bc2ba59385fef03b9ef939090c11f456533f29db049580b719ebafdf51ff5cb143ba	\\xfcaabc4835f8ef0a3b1e2019	\\xb61d08a2debc62214d9e5f77ebc366e7	2026-03-17 20:05:12.194613+00	\N	\N
009698dc-5747-424b-bf39-98e7a8e03a50	b7270a8b-868a-405e-bc67-d342bd40f029	1	\\xcd94d9533db669d81fd77d9582d5b07771e62d0abd63f82f479549ea511646554d4edf856b9424afc46fd4c63fda83e00a597d8dbf4e0888889a7eaea323d308ed17bb50	\\x5be181b389392363bc881ba2	\\xc0495bae8399387fa03df0a08b9369fd	2026-03-17 20:06:04.908968+00	\N	\N
be6a870c-5be4-46be-b2a2-a0357fa08b3f	4dea7b58-855d-4482-81c0-38ce46b2f3b2	1	\\x1e96c6c5d97de063ca589f715b6239693de7a34ac4b6f1491e6f90998e6b02331dc6475b0acce3b64d0f43304bfbf4e026b9093ddf7c8226c49ef4905492c200aa3a905e	\\x50ed4b7f91cbffd099a1d361	\\x38bd6dc71ed9345979e040e010f88fe8	2026-03-17 20:06:04.919194+00	\N	\N
5fe9e456-e2a2-4788-8950-d923518994f2	2cfae847-ed61-45d2-ba23-6687c42c03ad	1	\\xa19c23ec08c47a4d4837a68021b35ff88876c91c9e2383c6aa0c0c8845e4902a9b76e6	\\x93f5f026c896b15efd3b5b6f	\\x1a3bc98a12e55b74c5bcee9aab0eee05	2026-03-17 20:06:04.990133+00	\N	\N
809d33e2-48d6-4388-9848-6e90231f2728	c2c30f59-882e-4cb8-b033-4b36d3ea4b18	1	\\x1193765778088eeb492be1a118dfb00f44e32c069760f0ef05e8ea6865a1afb41105c8c49a9bbd58a170d76a18ba0d918836dd4f86ba09dcb94d3fa842de8bc29f7b28cc	\\x095aaa70773b955cdb264420	\\x7eef311cad8e5fe7a6904f123198f49f	2026-03-17 20:06:05.194535+00	\N	\N
10a6d900-bf5e-449b-b22a-45dd5ae9cdec	47535c2e-e238-40f0-b947-6fecb1359523	1	\\xea402e836cbc45db0b3ffa521ea75f52cc3a7463d18123b3ef58d5b1dd77cee43b427ebd1a	\\xe1c2de3c243bc67db358a5e4	\\x9e77063e47375f2946655820eb691171	2026-03-17 20:06:33.055921+00	\N	\N
\.


--
-- Name: vault_audit vault_audit_pkey; Type: CONSTRAINT; Schema: agent_vault; Owner: -
--

ALTER TABLE ONLY agent_vault.vault_audit
    ADD CONSTRAINT vault_audit_pkey PRIMARY KEY (id);


--
-- Name: vault_secrets vault_secrets_pkey; Type: CONSTRAINT; Schema: agent_vault; Owner: -
--

ALTER TABLE ONLY agent_vault.vault_secrets
    ADD CONSTRAINT vault_secrets_pkey PRIMARY KEY (id);


--
-- Name: vault_secrets vault_secrets_project_id_name_key; Type: CONSTRAINT; Schema: agent_vault; Owner: -
--

ALTER TABLE ONLY agent_vault.vault_secrets
    ADD CONSTRAINT vault_secrets_project_id_name_key UNIQUE (project_id, name);


--
-- Name: vault_versions vault_versions_pkey; Type: CONSTRAINT; Schema: agent_vault; Owner: -
--

ALTER TABLE ONLY agent_vault.vault_versions
    ADD CONSTRAINT vault_versions_pkey PRIMARY KEY (id);


--
-- Name: idx_vault_audit_name; Type: INDEX; Schema: agent_vault; Owner: -
--

CREATE INDEX idx_vault_audit_name ON agent_vault.vault_audit USING btree (secret_name, created_at);


--
-- Name: idx_vault_audit_project; Type: INDEX; Schema: agent_vault; Owner: -
--

CREATE INDEX idx_vault_audit_project ON agent_vault.vault_audit USING btree (project_id, created_at);


--
-- Name: idx_vault_secrets_project; Type: INDEX; Schema: agent_vault; Owner: -
--

CREATE INDEX idx_vault_secrets_project ON agent_vault.vault_secrets USING btree (project_id);


--
-- Name: idx_vault_versions_secret; Type: INDEX; Schema: agent_vault; Owner: -
--

CREATE INDEX idx_vault_versions_secret ON agent_vault.vault_versions USING btree (secret_id, version);


--
-- Name: vault_versions vault_versions_secret_id_fkey; Type: FK CONSTRAINT; Schema: agent_vault; Owner: -
--

ALTER TABLE ONLY agent_vault.vault_versions
    ADD CONSTRAINT vault_versions_secret_id_fkey FOREIGN KEY (secret_id) REFERENCES agent_vault.vault_secrets(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 4eQ8sLg0PYaYHvmMd7YfYlW9GUOcvUjLAP286JGzO6kFlULIxuBz0VdUf1qiGzb

