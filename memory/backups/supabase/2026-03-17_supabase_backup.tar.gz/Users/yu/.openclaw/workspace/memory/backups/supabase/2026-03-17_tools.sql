--
-- PostgreSQL database dump
--

\restrict M5zkm127v4SDAvp32iulKfWsYz9fUG6hnKTdQzzf76SwypWrqGKOdAls4Buc3vN

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.9 (Ubuntu 17.9-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: tools; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA tools;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: api_keys; Type: TABLE; Schema: tools; Owner: -
--

CREATE TABLE tools.api_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    key_hash text NOT NULL,
    key_prefix text NOT NULL,
    name text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used timestamp with time zone,
    revoked_at timestamp with time zone
);


--
-- Name: billing_events; Type: TABLE; Schema: tools; Owner: -
--

CREATE TABLE tools.billing_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    type text NOT NULL,
    amount_pence integer NOT NULL,
    credits_added integer NOT NULL,
    stripe_id text,
    crypto_tx_hash text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: projects; Type: TABLE; Schema: tools; Owner: -
--

CREATE TABLE tools.projects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    plan text DEFAULT 'dev'::text NOT NULL,
    credits integer DEFAULT 100 NOT NULL,
    stripe_customer_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: usage_events; Type: TABLE; Schema: tools; Owner: -
--

CREATE TABLE tools.usage_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    tool text NOT NULL,
    credits_used integer NOT NULL,
    duration_ms integer,
    success boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: tools; Owner: -
--

COPY tools.api_keys (id, project_id, key_hash, key_prefix, name, created_at, last_used, revoked_at) FROM stdin;
6d2c36dd-c295-49d5-b103-bfaa9f1473ac	ad412b44-6f03-405f-9c17-fd2450056258	$2b$10$A0MN9Ai67j.4ImdVbcbJoerdN95vHpfl.5nKIcmkvdG/jABZ.76V2	at_epjl1ie3	default	2026-03-11 16:44:51.604647+00	\N	\N
2e9920f5-edca-4532-8661-b70ec5bbb46c	6931bd47-6a4d-43f7-82ce-878c2cd3e587	$2b$10$gCqGOEjco/q8/dqTi0TmX./qSY02P29PHxHvrBcXvzLXmBEppIFP2	at_ljBOYWEu	default	2026-03-16 19:07:24.326573+00	\N	\N
252ba43d-338e-4d0f-a601-e6ae211ab41f	2a8f34a1-7675-4cf2-9ec9-8cd27fa7c609	$2b$10$MJQlTw./akqjITLzykTwh.RS8.knhssz42iakGI5oyXY/irxr6X02	at_xuJVvecD	default	2026-03-16 19:07:53.75024+00	\N	\N
27514b5b-36eb-4ec8-8ee1-3305511acb4b	fbe58d27-dfdd-4a63-bce9-b2cad00f6081	$2b$10$PUOo7sbmBk5cLs07EoG/SeOjFEzXjxVGDc227T5jK9M5zCSBjC8lq	at_djSJeSYv	default	2026-03-16 19:25:44.232741+00	\N	\N
14b1c3cc-d81d-4428-a461-f0943f5f88a4	58642346-ded7-4e59-9177-0e29ffc583c8	$2b$10$vgvWI0jSF3Fz9x8ZJRPEEOvXurvGDTPZ3p3Q2Q4TTvbTi89eRZzGC	at_-ZiQA9TB	default	2026-03-16 19:31:59.070163+00	\N	\N
39603054-c56a-4ca4-b38f-ae543591b213	c642e8c7-48b7-493a-ae19-7c5e0e53dc3e	$2b$10$Ng29yMHH4GoxkTKubeKweOL.RG1Hr1RexWAXr4GWw/aZEJmCdRRMO	at_Stzrk1iz	default	2026-03-16 21:38:53.782526+00	\N	\N
ddb161f1-8297-4e20-a21a-255061b6a7cf	5c733015-a6a3-4631-93a6-ae9a8e296d4b	$2b$10$WGmXHwRlxMO1ocic9sPS.u7wAPpYRuI6bXlsncxHTHaB7xFfqvXjS	at_tcUYkmCk	default	2026-03-16 22:34:17.320828+00	2026-03-16 22:34:20.498+00	\N
7b6a3822-fda3-46f5-8a39-28c1fb69fdb4	8f01cb86-c958-4c5a-8bbd-10eebc072ca5	$2b$10$VPtAFx8X1XI9WW73cKSKgeNrhmNGGQfvXESLfvWbq2l50N/mlHhae	at_0VO5uLU5	default	2026-03-11 18:41:59.272996+00	\N	\N
2ed72c46-5c4a-492c-82a1-411cc15064f9	9572108d-33bb-4d37-b21c-8470f38deac8	$2b$10$4nKLNWjwNmD0gOhQek54m.VuY9nnL/svvj3IocgUshRh543d4ZrkS	at_Nl0Sg0VG	default	2026-03-17 00:22:06.641992+00	2026-03-17 00:22:10.304+00	\N
c340a623-575c-4fea-8370-36f06b5db86e	88c28d71-789d-48d5-b6ce-eefb1a6b4d9f	$2b$10$UbukQCtejrgthbfHA/OkZeHm3M8lsA6Yb91ixt1LfgfHrBSGLokge	at_H0FV58_F	default	2026-03-17 14:09:03.296146+00	2026-03-17 14:09:04.327532+00	\N
5237af0d-08cd-4604-bd72-48f182bf479f	833530b7-b316-4667-bd12-6965d7faa8e7	$2b$10$H27j9vmBXbfMoQE.7AKQieVQCKa16mBc943m9v6ntijEWxijtJwQO	at_CaP7Pv0S	default	2026-03-12 04:40:43.114155+00	2026-03-12 06:54:13.813+00	\N
8cb43fa7-50bd-42dd-b382-2a13e2273f98	03413e2c-fc84-4f76-8816-0cd50732c020	$2b$10$7V3SiI7xomONub2ChI8zheTcS9Ajkq3Y59ekXCZKEsfS/wVhLctAu	at_5tdem5nN	default	2026-03-17 00:22:45.886927+00	2026-03-17 00:22:47.34+00	\N
a541e301-6a29-44c8-9760-21b78bfdc7b1	91f79e96-86b9-424b-946d-593f4ee958e6	$2b$10$itYE5UMehJzelHWMlWTdue9dLn9hYhWIJ618M2gldElwj8UQDqb9y	at_bGo3aSAu	default	2026-03-16 22:44:00.538309+00	2026-03-16 22:44:37.146957+00	\N
185f02c4-9852-4bb0-bc0c-56eef7ec27fa	34e4b3ee-738c-45c8-bb87-452d1da18627	$2b$10$7rE0krDnjRk7DHYmlTueyeUhi.SR9poj2qwpjdA2xOlixdWLv1Qy2	at_dFUwvzfg	default	2026-03-16 22:53:11.857208+00	2026-03-16 22:53:15.597+00	\N
aa72114f-00b8-4b7c-bf37-248438351094	e184bc9a-aa05-4479-8436-8dfbecbc7386	$2b$10$u1wkL6oVTkYWclzv0Ijhh.W946MDPSjVrWGQMZh47pMX7210m.Fhe	at_wydQcnOj	default	2026-03-16 21:51:35.767182+00	\N	\N
16d11356-fe63-4320-8dbc-94675d3231ef	67352a08-7a89-4359-8a19-749010b37c03	$2b$10$64FT..OozaQKu..o.QLyAOdkZxqQPPFomv28PAu9MskOqDAnz4fPS	at_g6LbVRHy	default	2026-03-16 23:26:51.447904+00	2026-03-16 23:27:00.019+00	\N
ce4eb451-5202-4421-aefa-f8df97eca724	2e8ec8c2-12df-4279-bc6f-47355b028af0	$2b$10$8SymHFSQ8Iqgc70jtNbQeumS64ZXNQHwPsbiGRCqdBVSzTChGv8Ge	at_sv5kifaX	e2e-test-key	2026-03-16 21:53:04.009488+00	\N	2026-03-16 21:55:12.759+00
0bac8504-971c-4b2f-8d07-1da77b423f5b	32877af4-56bf-4135-a985-286f1d9da9a2	$2b$10$cLD0Rsy.hUEZN.qTm3W4E.i4die7pgNf/QY5rps7sXAa7w/wBAIEu	at_OoTor_u1	default	2026-03-16 23:46:58.336441+00	2026-03-16 23:47:11.101+00	\N
3d03ecc6-6b2e-40b5-af52-a524102196ba	54b26f66-10ff-466e-a1ab-c793c4d65958	$2b$10$KS.U2d6Zv2/y/g8ghqc4LeXziPdjIb/WfZNGjINMXCZ6fuqo.dxmK	at_uc0AQCj_	default	2026-03-12 09:00:38.420236+00	2026-03-12 13:12:32.366804+00	\N
92a73de8-0889-4c73-b341-9e89f5767fe3	086adcde-b421-4242-b2a1-e5a89b4f66e2	$2b$10$OXxXsLIiVHhfGgrEilLOOOAUxv9H7A2sKjat3bwudtLuOzW.dBphC	at_TlqPJXiN	default	2026-03-16 12:20:26.49036+00	\N	\N
3d09a7cc-db88-4b60-8c25-718968a294e6	010f3f46-0d61-4b3b-a35b-704c40b016cb	$2b$10$.jhC0CTX6RnO2ty9kGdbPuuq8ZDJ4AOHgBF95i4MCBYiWQ7ElXWVG	at_7x5Q1lhA	default	2026-03-16 23:48:22.850412+00	2026-03-16 23:48:24.578+00	\N
b6480fb7-10c4-4a87-b8ad-5e2fba5fad9b	f81104f1-ccd0-4656-9dbb-80359303c6f9	$2b$10$Q4MU7w5kDLZsdMENfl1YOuKAZNxfIy2ki3Q0W3vvXOFYpgWQRfnpa	at_B598r51X	default	2026-03-16 23:54:15.277836+00	\N	\N
f7e761ef-0087-4c87-a3f7-71f58f0fe5e6	43f7ae80-ee09-4063-a344-4e7953d6abc9	$2b$10$o6wFPqkiMXFM2EyF2WVYru65KjTEOeF0LikEwLJJj1Qwg/JrMzP/q	at_W0nIkvbQ	default	2026-03-11 17:08:38.302456+00	2026-03-11 21:43:45.387+00	\N
c19f37a0-5e57-4e5e-b6f7-ee16c634d37a	84f2ab32-8d99-42c4-bc1c-680e51ca4b81	$2b$10$yIFU5SBKdGUPrZupVuxPbuHZ7Bdft.YzNpy0poq3Om6hfezZJrmZy	at_cEZIPX4D	default	2026-03-11 21:43:52.796606+00	2026-03-11 21:43:53.929+00	\N
7a124020-2479-4b0d-aa65-1f6a222b24e7	2e8ec8c2-12df-4279-bc6f-47355b028af0	$2b$10$uKt5kmlxNXd6ph8XLZk5JeYLYYgMuebwpzQzHiHwKYFQUfsjvQ.ly	at_UFSZMjWn	default	2026-03-16 19:02:40.648093+00	2026-03-16 22:10:21.388838+00	\N
9d4a2d41-286a-4413-9918-650d4f0b116b	b2d51a63-f038-4600-a9d0-a4d7968b24a1	$2b$10$fZGCoD8RDX7xtgRwAc3QMeYedpupScJC8eYlqigwwdhVp9DRozA1O	at_IFdXbwwk	default	2026-03-17 00:02:07.652477+00	2026-03-17 00:02:09.185+00	\N
2eccd1a2-eae2-43b1-949a-0742d97fd1e7	af30405c-6b2a-4a7d-b551-9f9a695ce45e	$2b$10$dPRaqdb8n1gzUBlMPT6qS.87yBagS93pxXki15/rLQnJ695PW7qJa	at_re6NcgoN	default	2026-03-17 00:06:48.634553+00	2026-03-17 00:06:49.266+00	\N
655d6d12-e6db-469d-9cd3-31e248bc5e5a	4dde2b5c-8e4b-4a00-b843-be044cdbb2cb	$2b$10$GUJyYqjbV9yZojr0CJRnQuMHnWyVFtfH4Jk7GYq16juPTlKLG9YUC	at_x7GQwRk0	default	2026-03-17 00:07:17.363003+00	2026-03-17 00:07:17.697+00	\N
b7fd2a9c-757f-4e0d-91aa-82cf89b5d255	5954c50f-f415-413d-872a-21f4d9c215e7	$2b$10$WrI1OPoNGIbzugMRiU./7u31ff486S8n4quqfYEamBeG9xCdDxVDC	at_bpB7n8xj	default	2026-03-16 19:04:48.339801+00	2026-03-16 19:05:00.239+00	\N
e07f27ce-538b-47c5-afcb-36b1fb1326ab	1ced6574-972b-46c0-add3-d4330b91ed1d	$2b$10$i8bN4YQydmhdwYeivBf/2u/EGIQc4audY0slNwwZ3C7e8umHW7ELW	at_YaPKjGjb	default	2026-03-16 19:07:01.599878+00	\N	\N
ec752fde-054b-4671-9e37-fea0e4fa8eac	e08aaecf-dd35-443b-8a66-b09a2e50c3ec	$2b$10$x7/79och17MuvQ88jGDxl.qYG/F.JPHzgBAUmFwdXf6mjZmNCs0UO	at_r4i4TJJT	default	2026-03-16 21:46:55.171047+00	2026-03-16 21:53:38.091+00	\N
db390f7a-6021-406b-af4f-1745a5c31f06	a022a844-7c2f-4050-97a3-adf56112cf7d	$2b$10$qNS0d/nGgmVmWO2/fhdFB.f6tVPrdHUbj2L4UgQ3uhh80OdMpGQrm	at_v3VECxnh	default	2026-03-16 22:04:37.387121+00	2026-03-16 22:11:46.961441+00	\N
2b78c947-52af-48a3-bf73-99eb358356ed	8864064e-e7b3-45d0-b1be-ee94c1e9a494	$2b$10$kTQ0ncXuMuN597asRPa/.evlJ5vdEQwS9JbHBG0Gc0TBtDNztuP6O	at_JWu5EIrm	default	2026-03-17 00:11:33.680926+00	2026-03-17 00:11:34.301+00	\N
2c1b671b-d568-424b-8823-c06353e6ecff	2d920096-4239-4e50-8844-651fd8bbfdc5	$2b$10$K0PnNay3ht4Z86n3YCS6bONN.VYsEUGZEJKUd3jai372ZQuEplqNi	at_2-SzLbgh	default	2026-03-17 00:14:21.854043+00	\N	\N
e5db50ff-2817-44c6-945c-d77e95ac6b09	ad6b815a-fe42-464f-968f-8b837df6a415	$2b$10$6mMRfLKzYZ9aWluIXOSDteDIIjUSkFdg8Fj6XAyGIZSksDDu27UJm	at_uK-Ztz-F	default	2026-03-17 00:14:43.763647+00	\N	\N
23d73f79-159e-41e8-9a88-91c2504e0e74	da2dccb9-b62a-4ffa-91c7-351185b21623	$2b$10$z2B4Y9qC9q0TbT2hXhZcaubC2b1OvtfeVD5B02WmMDQPw6VE7eIt6	at_SsGQZYZq	default	2026-03-17 00:15:22.826104+00	\N	\N
795b4a06-dd5c-4fbc-8357-216f02c81c79	532afb38-6b64-4921-8791-9a8c6268c6c2	$2b$10$ho6KskfPAmlm5XrdODMgNuLiSTURJqRx/uWOxW7XDMnUg.fDt97UC	at_TVxP9Tmy	default	2026-03-17 19:26:41.395192+00	2026-03-17 20:07:17.326+00	\N
5f357e9b-4a1f-4e4a-96c2-2d33126f2444	5861ce2d-8851-4403-b17c-db93eb5cf08a	$2b$10$eJdColqJIIhn/iejCUMjbOuwlB1xXvF5Puo9BJ2B1OTN0KYPWz4NS	at_AtZeRfOl	default	2026-03-17 14:06:40.14656+00	2026-03-17 14:07:52.423364+00	\N
d3b4a6cb-f0a9-464a-909b-7d4be21885fd	e74f8111-195d-45d3-9f47-784207ddc063	$2b$10$3IL/CPCS.Y6pNCGtwCW3D.Gn3gov2COFE.LtcoeHBXKZMyyq7UYNe	at_B2L_M1qr	default	2026-03-17 18:29:58.206841+00	2026-03-17 18:30:39.509+00	\N
0a407da9-cfa0-416a-b01a-06619656ebe9	a84d31d5-400e-449d-800b-0fbc062997e5	$2b$10$4jCLi.jXraSzdD6/lx0wPeHvu3zfI2zVgOoCKFfr5zTY5AG.6yUQC	at_WBuKLGh_	default	2026-03-17 16:18:46.091151+00	2026-03-17 16:26:57.51+00	\N
6f3d9e18-9475-4c63-9788-30bd9533aed5	abc10fba-1aa4-4b69-86ca-3f7c3b51e6fd	$2b$10$axOBcrutvIcDlesEG8SKU.omjl15A94XjZby7KHwPTyAWMDL1E.se	at_9T9yAsaw	default	2026-03-17 18:29:25.575189+00	\N	\N
288ac75a-4dc2-4d18-999f-a76eeb8a5967	47b6d379-b04e-4c5c-959c-f319b61c215e	$2b$10$gYWLz3yXE1rkuxZmmSzh3uVeVe/piQW66qezy3g4qbYR7O.6vryjO	at_VoQ7dTdL	default	2026-03-17 18:30:46.454922+00	2026-03-17 18:31:08.855657+00	\N
4e239ec6-30ca-4fe8-b784-c336a3df17b0	d0a3c2c9-ef21-4860-afd8-11da4d4be218	$2b$10$uzMvuIJJgfWZwpsp35032uZfoOy.iL/.KkLd1dt5cfjRoE/E2zOgG	at_Oj8vSDfH	default	2026-03-17 19:32:55.973059+00	2026-03-17 19:33:01.437272+00	\N
9c57873c-e2ee-433d-bf79-e020eca28bc8	c573f67f-913f-4a2f-9cf4-dbefb5e0335e	$2b$10$wPkgprOLUGNFsw2iTgLJDOIQP4s/tkMhjTEy3TQG4pv2EzTDWA1ru	at_YmUmxeys	default	2026-03-17 14:11:14.877824+00	2026-03-17 19:33:14.750893+00	\N
\.


--
-- Data for Name: billing_events; Type: TABLE DATA; Schema: tools; Owner: -
--

COPY tools.billing_events (id, project_id, type, amount_pence, credits_added, stripe_id, crypto_tx_hash, created_at) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: tools; Owner: -
--

COPY tools.projects (id, name, plan, credits, stripe_customer_id, created_at) FROM stdin;
32877af4-56bf-4135-a985-286f1d9da9a2	live-verify	dev	95	\N	2026-03-16 23:46:58.160184+00
a022a844-7c2f-4050-97a3-adf56112cf7d	thinking-agent-demo	dev	88	\N	2026-03-16 22:04:37.216346+00
5c733015-a6a3-4631-93a6-ae9a8e296d4b	thinking-agent-demo	dev	88	\N	2026-03-16 22:34:17.158759+00
91f79e96-86b9-424b-946d-593f4ee958e6	thinking-demo-final	dev	88	\N	2026-03-16 22:44:00.425611+00
086adcde-b421-4242-b2a1-e5a89b4f66e2	test-push-verify	dev	68	\N	2026-03-16 12:20:26.313051+00
2e8ec8c2-12df-4279-bc6f-47355b028af0	gamma-test	dev	68	\N	2026-03-16 19:02:40.473145+00
ad412b44-6f03-405f-9c17-fd2450056258	validation-test	dev	26	\N	2026-03-11 16:44:51.435826+00
43f7ae80-ee09-4063-a344-4e7953d6abc9	beta-test	dev	26	\N	2026-03-11 17:08:38.149313+00
8f01cb86-c958-4c5a-8bbd-10eebc072ca5	my-agent	dev	33	\N	2026-03-11 18:41:59.167995+00
84f2ab32-8d99-42c4-bc1c-680e51ca4b81	execute-test	dev	41	\N	2026-03-11 21:43:52.690898+00
833530b7-b316-4667-bd12-6965d7faa8e7	beta-test-execute	dev	42	\N	2026-03-12 04:40:42.952172+00
54b26f66-10ff-466e-a1ab-c793c4d65958	test-signup-flow	dev	47	\N	2026-03-12 09:00:38.23485+00
5954c50f-f415-413d-872a-21f4d9c215e7	isolation-test	dev	75	\N	2026-03-16 19:04:48.233646+00
1ced6574-972b-46c0-add3-d4330b91ed1d	hb-check	dev	75	\N	2026-03-16 19:07:01.481238+00
6931bd47-6a4d-43f7-82ce-878c2cd3e587	hb-fix-test	dev	75	\N	2026-03-16 19:07:24.218721+00
2a8f34a1-7675-4cf2-9ec9-8cd27fa7c609	debug-test	dev	75	\N	2026-03-16 19:07:53.643197+00
fbe58d27-dfdd-4a63-bce9-b2cad00f6081	postfix-verify	dev	75	\N	2026-03-16 19:25:44.05879+00
58642346-ded7-4e59-9177-0e29ffc583c8	alpha-hive-test	dev	75	\N	2026-03-16 19:31:58.93197+00
c642e8c7-48b7-493a-ae19-7c5e0e53dc3e	beta-e2e-test	dev	75	\N	2026-03-16 21:38:53.610642+00
e08aaecf-dd35-443b-8a66-b09a2e50c3ec	instant-test	dev	75	\N	2026-03-16 21:46:55.01519+00
e184bc9a-aa05-4479-8436-8dfbecbc7386	e2e-full-test	dev	79	\N	2026-03-16 21:51:35.661476+00
34e4b3ee-738c-45c8-bb87-452d1da18627	identity-timeout-test	dev	90	\N	2026-03-16 22:53:11.694976+00
67352a08-7a89-4359-8a19-749010b37c03	credit-weight-test	dev	90	\N	2026-03-16 23:26:51.277103+00
010f3f46-0d61-4b3b-a35b-704c40b016cb	final-live-check	dev	100	\N	2026-03-16 23:48:22.742615+00
f81104f1-ccd0-4656-9dbb-80359303c6f9	vault-debug	dev	100	\N	2026-03-16 23:54:15.101546+00
b2d51a63-f038-4600-a9d0-a4d7968b24a1	vault-final-test	dev	100	\N	2026-03-17 00:02:07.496102+00
af30405c-6b2a-4a7d-b551-9f9a695ce45e	vault-zod-fix	dev	100	\N	2026-03-17 00:06:48.501698+00
4dde2b5c-8e4b-4a00-b843-be044cdbb2cb	vault-debug2	dev	100	\N	2026-03-17 00:07:17.252729+00
8864064e-e7b3-45d0-b1be-ee94c1e9a494	vault-debug3	dev	100	\N	2026-03-17 00:11:33.516386+00
2d920096-4239-4e50-8844-651fd8bbfdc5	vault-tags-fix	dev	100	\N	2026-03-17 00:14:21.719702+00
ad6b815a-fe42-464f-968f-8b837df6a415	vault-final	dev	100	\N	2026-03-17 00:14:43.65704+00
da2dccb9-b62a-4ffa-91c7-351185b21623	v-test	dev	100	\N	2026-03-17 00:15:22.718417+00
9572108d-33bb-4d37-b21c-8470f38deac8	vault-v8	dev	100	\N	2026-03-17 00:22:06.457293+00
03413e2c-fc84-4f76-8816-0cd50732c020	vault-read-test	dev	100	\N	2026-03-17 00:22:45.778957+00
5861ce2d-8851-4403-b17c-db93eb5cf08a	bootstrap-test	dev	100	\N	2026-03-17 14:06:39.97396+00
88c28d71-789d-48d5-b6ce-eefb1a6b4d9f	bootstrap-test	dev	100	\N	2026-03-17 14:09:03.186963+00
c573f67f-913f-4a2f-9cf4-dbefb5e0335e	kingdom-test	dev	100	\N	2026-03-17 14:11:14.766818+00
a84d31d5-400e-449d-800b-0fbc062997e5	kingdom-civilisation	dev	100	\N	2026-03-17 16:18:45.921724+00
abc10fba-1aa4-4b69-86ca-3f7c3b51e6fd	hn-demo-test	dev	100	\N	2026-03-17 18:29:25.39894+00
e74f8111-195d-45d3-9f47-784207ddc063	hn-demo-test2	dev	100	\N	2026-03-17 18:29:58.100807+00
47b6d379-b04e-4c5c-959c-f319b61c215e	hn-demo-test3	dev	100	\N	2026-03-17 18:30:46.342206+00
532afb38-6b64-4921-8791-9a8c6268c6c2	beta-mac-studio	dev	100	\N	2026-03-17 19:26:41.204455+00
d0a3c2c9-ef21-4860-afd8-11da4d4be218	alpha-citizen	dev	100	\N	2026-03-17 19:32:55.814014+00
\.


--
-- Data for Name: usage_events; Type: TABLE DATA; Schema: tools; Owner: -
--

COPY tools.usage_events (id, project_id, tool, credits_used, duration_ms, success, created_at) FROM stdin;
e02768a1-62b6-44ee-961d-24fa8cad3298	43f7ae80-ee09-4063-a344-4e7953d6abc9	search	1	\N	t	2026-03-11 18:21:36.314925+00
964b88dc-0695-4878-ac71-ac185e8d3da0	43f7ae80-ee09-4063-a344-4e7953d6abc9	search	0	0	f	2026-03-11 18:21:36.342006+00
9ddf04bd-2642-47df-870a-49e0d257ded6	43f7ae80-ee09-4063-a344-4e7953d6abc9	search	1	\N	t	2026-03-11 18:22:05.837815+00
d4f834c7-0fcd-49a9-8cfa-37906ed5c14c	43f7ae80-ee09-4063-a344-4e7953d6abc9	search	0	0	f	2026-03-11 18:22:05.869449+00
73eeace5-3831-4161-98df-a201ed5cc67e	43f7ae80-ee09-4063-a344-4e7953d6abc9	search	1	\N	t	2026-03-11 18:23:59.393543+00
9df023ee-7abf-4494-8ce3-c4b09b8e9835	43f7ae80-ee09-4063-a344-4e7953d6abc9	search	0	440	f	2026-03-11 18:23:59.864127+00
30d4c76f-1b37-48dc-926d-38d849e59927	43f7ae80-ee09-4063-a344-4e7953d6abc9	search	1	\N	t	2026-03-11 18:30:55.702879+00
38892347-304a-4802-8cb4-52058444e181	43f7ae80-ee09-4063-a344-4e7953d6abc9	scrape	2	\N	t	2026-03-11 18:31:13.386829+00
842b24b2-2842-4438-8560-b5c7c92e3ef9	43f7ae80-ee09-4063-a344-4e7953d6abc9	search	1	\N	t	2026-03-11 18:40:58.808534+00
2059ce0c-06aa-4fb9-bec9-505586bd3f1e	43f7ae80-ee09-4063-a344-4e7953d6abc9	execute	1	\N	t	2026-03-11 20:45:32.956585+00
c6ead801-01bf-4b80-a41b-859b0c0006c9	43f7ae80-ee09-4063-a344-4e7953d6abc9	execute	0	5	f	2026-03-11 20:45:32.990049+00
28fa03a3-f97c-44d0-abc9-0ef70fe097c2	43f7ae80-ee09-4063-a344-4e7953d6abc9	execute	1	\N	t	2026-03-11 21:12:28.705543+00
8d80339a-ab62-4349-9b41-ae70c688fee7	43f7ae80-ee09-4063-a344-4e7953d6abc9	execute	1	\N	t	2026-03-11 21:12:29.918726+00
80db2939-50c1-4a67-b673-13a6f1ba29be	43f7ae80-ee09-4063-a344-4e7953d6abc9	execute	0	6	f	2026-03-11 21:12:29.948536+00
030c1899-8c39-4357-a112-5a4c49ef08b0	43f7ae80-ee09-4063-a344-4e7953d6abc9	execute	1	\N	t	2026-03-11 21:12:36.540463+00
96af6710-2233-4b11-9cf4-0f64dc742a84	43f7ae80-ee09-4063-a344-4e7953d6abc9	execute	0	1	f	2026-03-11 21:12:36.563381+00
495bc99f-3026-42f9-b757-ebeb64647283	43f7ae80-ee09-4063-a344-4e7953d6abc9	execute	1	\N	t	2026-03-11 21:17:33.595983+00
5c205a10-2fcb-46c2-922d-f277d8b7a6ae	43f7ae80-ee09-4063-a344-4e7953d6abc9	execute	1	\N	t	2026-03-11 21:17:34.786352+00
72dda1f8-bf6f-45f9-97b9-772c4e7b0beb	43f7ae80-ee09-4063-a344-4e7953d6abc9	execute	0	9	f	2026-03-11 21:17:34.820225+00
bf23aee7-35b9-4bdd-95b3-d3397a7e466f	43f7ae80-ee09-4063-a344-4e7953d6abc9	execute	1	\N	t	2026-03-11 21:43:26.55166+00
08d668a2-0d2d-4d27-ae3a-46f9cd2c8f60	43f7ae80-ee09-4063-a344-4e7953d6abc9	execute	0	1	f	2026-03-11 21:43:26.578267+00
a5241293-d42a-4231-a7b0-96393fb9943b	43f7ae80-ee09-4063-a344-4e7953d6abc9	execute	1	\N	t	2026-03-11 21:43:28.561061+00
4663d81c-54cc-4bbc-90b3-8d21a32fc87d	43f7ae80-ee09-4063-a344-4e7953d6abc9	execute	0	84	f	2026-03-11 21:43:28.667841+00
15d52c14-ed0b-4d83-8046-a58064074db2	84f2ab32-8d99-42c4-bc1c-680e51ca4b81	execute	1	\N	t	2026-03-11 21:43:54.005131+00
fd36ffdb-d889-4f12-a6b1-4d46b0cb4e91	833530b7-b316-4667-bd12-6965d7faa8e7	execute	1	\N	t	2026-03-12 04:40:53.791911+00
be8a2b1c-e914-461b-9dc4-750697f96cef	833530b7-b316-4667-bd12-6965d7faa8e7	execute	1	\N	t	2026-03-12 04:40:55.340597+00
cf6699c2-2dca-4d18-b2d7-57f09515be40	833530b7-b316-4667-bd12-6965d7faa8e7	execute	1	\N	t	2026-03-12 04:40:56.709332+00
31f50bbb-d9a9-490b-bbc9-9c0c4980110e	833530b7-b316-4667-bd12-6965d7faa8e7	execute	1	\N	t	2026-03-12 05:51:35.734669+00
3d538e01-3a0b-4c9c-a8c8-7fe2e81bd563	833530b7-b316-4667-bd12-6965d7faa8e7	search	1	\N	t	2026-03-12 05:51:58.606199+00
0d8174ef-6712-4548-be48-a4f9612ce133	54b26f66-10ff-466e-a1ab-c793c4d65958	document	3	\N	t	2026-03-12 11:42:09.826731+00
f872e210-7569-42ba-82a6-8ce1d9a3d0b7	54b26f66-10ff-466e-a1ab-c793c4d65958	document	0	29	f	2026-03-12 11:42:09.886369+00
d0c176ce-47db-4802-999f-762d110bb90d	54b26f66-10ff-466e-a1ab-c793c4d65958	document	3	\N	t	2026-03-12 11:42:46.717335+00
cae57742-c095-4751-be3f-bd279d6b2407	54b26f66-10ff-466e-a1ab-c793c4d65958	document	0	6	f	2026-03-12 11:42:46.746869+00
53520381-a441-4ab0-a0fc-182ab730aff8	54b26f66-10ff-466e-a1ab-c793c4d65958	document	3	\N	t	2026-03-12 11:48:16.661455+00
78f89fe5-32fb-469e-9726-2106ad88486a	54b26f66-10ff-466e-a1ab-c793c4d65958	scrape	2	\N	t	2026-03-12 11:48:22.354071+00
5a4f5543-1029-4c80-ad20-7788ae7b8d3d	54b26f66-10ff-466e-a1ab-c793c4d65958	search	1	\N	t	2026-03-12 11:49:58.531099+00
80179ab1-34c2-4ecd-a748-912fe72f8511	54b26f66-10ff-466e-a1ab-c793c4d65958	document	3	\N	t	2026-03-12 11:50:07.334621+00
ab5346e1-93ef-4e82-a122-fa1d9af69667	54b26f66-10ff-466e-a1ab-c793c4d65958	search	1	\N	t	2026-03-12 11:55:22.166297+00
4a8a304f-58a7-43e8-85d6-c6c850cf1d6b	54b26f66-10ff-466e-a1ab-c793c4d65958	document	3	\N	t	2026-03-12 11:55:25.939956+00
41eb2f2a-c79b-4f6b-b3e1-0240dac5da15	54b26f66-10ff-466e-a1ab-c793c4d65958	execute	1	\N	t	2026-03-12 11:55:27.25012+00
2055dc11-86e4-4f93-b1b8-2511adf67e3f	54b26f66-10ff-466e-a1ab-c793c4d65958	search	1	\N	t	2026-03-12 11:55:37.541234+00
9ce31865-bcea-4058-be79-bf86a10d1e6a	2e8ec8c2-12df-4279-bc6f-47355b028af0	search	1	\N	t	2026-03-16 19:04:10.897341+00
3cd6a0b4-6057-4d83-9cdd-9be7ea2cd480	2e8ec8c2-12df-4279-bc6f-47355b028af0	scrape	2	\N	t	2026-03-16 19:04:14.393587+00
8c5da265-8272-4422-a371-01e53b5d30ad	2e8ec8c2-12df-4279-bc6f-47355b028af0	execute	1	\N	t	2026-03-16 19:04:16.62501+00
120ce172-3e88-4338-ad9a-2850b79fdc7c	2e8ec8c2-12df-4279-bc6f-47355b028af0	document	3	\N	t	2026-03-16 19:04:39.848689+00
90401605-83f6-4339-be4c-7bf5c1406b86	e08aaecf-dd35-443b-8a66-b09a2e50c3ec	search	1	\N	t	2026-03-16 21:46:59.053095+00
99704b94-733d-4199-873f-08a3399f12a0	e08aaecf-dd35-443b-8a66-b09a2e50c3ec	execute	1	\N	t	2026-03-16 21:47:02.874352+00
1e11b8a3-7d53-4f5e-98f7-36b0c5ddc9f6	e08aaecf-dd35-443b-8a66-b09a2e50c3ec	search	1	\N	t	2026-03-16 21:47:43.900641+00
716699a6-d355-4bdc-9a4f-43c5b18f022a	e08aaecf-dd35-443b-8a66-b09a2e50c3ec	execute	1	\N	t	2026-03-16 21:47:48.083435+00
7d4d1634-2757-4e88-aa39-6f1a29da7572	e08aaecf-dd35-443b-8a66-b09a2e50c3ec	search	1	\N	t	2026-03-16 21:52:08.40519+00
fdc7c99c-0d0f-4f7c-9b12-78a41f8d4d38	e08aaecf-dd35-443b-8a66-b09a2e50c3ec	scrape	2	\N	t	2026-03-16 21:52:17.466145+00
84134c85-a7a1-4f34-8ecb-149f60ecab6f	e08aaecf-dd35-443b-8a66-b09a2e50c3ec	execute	1	\N	t	2026-03-16 21:52:22.05964+00
75b674c7-80b1-49a5-94db-3b5240251d3d	e08aaecf-dd35-443b-8a66-b09a2e50c3ec	execute	1	\N	t	2026-03-16 21:52:24.288415+00
6fd610c0-0a60-4360-b641-1141b38d7ada	e08aaecf-dd35-443b-8a66-b09a2e50c3ec	execute	1	\N	t	2026-03-16 21:53:26.154282+00
4fe58c8c-efe7-4aa7-a06c-19b397fafcdb	2e8ec8c2-12df-4279-bc6f-47355b028af0	search	1	\N	t	2026-03-16 21:55:03.72878+00
cb5b2666-2953-489b-abb4-bdebef0f50ed	2e8ec8c2-12df-4279-bc6f-47355b028af0	execute	1	\N	t	2026-03-16 21:55:08.081815+00
cf7f6dae-133e-4d8f-8e22-0bdc92bf5dbb	2e8ec8c2-12df-4279-bc6f-47355b028af0	execute	1	\N	t	2026-03-16 21:55:10.148339+00
ed6f905d-5adb-4fd8-941a-2896d183532a	91f79e96-86b9-424b-946d-593f4ee958e6	search	1	\N	t	2026-03-16 22:44:27.065045+00
7c8c9414-7b99-4a71-b918-c728923ff1a8	91f79e96-86b9-424b-946d-593f4ee958e6	execute	1	\N	t	2026-03-16 22:44:34.959586+00
22bde191-b547-470d-b0ee-e5674f2f24a2	67352a08-7a89-4359-8a19-749010b37c03	search	5	\N	t	2026-03-16 23:27:01.220104+00
dd3ceb78-b827-48ef-8248-0a01391ce8b9	32877af4-56bf-4135-a985-286f1d9da9a2	search	5	\N	t	2026-03-16 23:47:12.305476+00
\.


--
-- Name: api_keys api_keys_key_hash_unique; Type: CONSTRAINT; Schema: tools; Owner: -
--

ALTER TABLE ONLY tools.api_keys
    ADD CONSTRAINT api_keys_key_hash_unique UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: tools; Owner: -
--

ALTER TABLE ONLY tools.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: billing_events billing_events_pkey; Type: CONSTRAINT; Schema: tools; Owner: -
--

ALTER TABLE ONLY tools.billing_events
    ADD CONSTRAINT billing_events_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: tools; Owner: -
--

ALTER TABLE ONLY tools.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: usage_events usage_events_pkey; Type: CONSTRAINT; Schema: tools; Owner: -
--

ALTER TABLE ONLY tools.usage_events
    ADD CONSTRAINT usage_events_pkey PRIMARY KEY (id);


--
-- Name: idx_api_keys_project; Type: INDEX; Schema: tools; Owner: -
--

CREATE INDEX idx_api_keys_project ON tools.api_keys USING btree (project_id);


--
-- Name: idx_billing_project; Type: INDEX; Schema: tools; Owner: -
--

CREATE INDEX idx_billing_project ON tools.billing_events USING btree (project_id);


--
-- Name: idx_usage_project_time; Type: INDEX; Schema: tools; Owner: -
--

CREATE INDEX idx_usage_project_time ON tools.usage_events USING btree (project_id, created_at);


--
-- PostgreSQL database dump complete
--

\unrestrict M5zkm127v4SDAvp32iulKfWsYz9fUG6hnKTdQzzf76SwypWrqGKOdAls4Buc3vN

