--
-- PostgreSQL database dump
--

\restrict NfiRp1yoPSN76o9TSRYOahBFRQSgaFchnm68azIXw1dU85Yk69ztw8EDxQeiZVx

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.9 (Ubuntu 17.9-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: economy; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA economy;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: api_keys; Type: TABLE; Schema: economy; Owner: -
--

CREATE TABLE economy.api_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    key_hash text NOT NULL,
    key_prefix text NOT NULL,
    name text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used timestamp with time zone,
    revoked_at timestamp with time zone
);


--
-- Name: billing_events; Type: TABLE; Schema: economy; Owner: -
--

CREATE TABLE economy.billing_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    wallet_id uuid,
    type text NOT NULL,
    amount_pence integer NOT NULL,
    credits_added bigint NOT NULL,
    stripe_id text,
    crypto_tx_hash text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: escrows; Type: TABLE; Schema: economy; Owner: -
--

CREATE TABLE economy.escrows (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    creator_wallet uuid NOT NULL,
    worker_wallet uuid,
    amount bigint NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'funded'::text NOT NULL,
    deadline timestamp with time zone,
    released_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: policies; Type: TABLE; Schema: economy; Owner: -
--

CREATE TABLE economy.policies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    wallet_id uuid NOT NULL,
    max_per_transaction bigint,
    max_per_hour bigint,
    max_per_day bigint,
    allowed_recipients text[],
    requires_approval_above bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: projects; Type: TABLE; Schema: economy; Owner: -
--

CREATE TABLE economy.projects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    plan text DEFAULT 'free'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stripe_events; Type: TABLE; Schema: economy; Owner: -
--

CREATE TABLE economy.stripe_events (
    stripe_event_id text NOT NULL,
    processed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: subscriptions; Type: TABLE; Schema: economy; Owner: -
--

CREATE TABLE economy.subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    stripe_customer_id text,
    stripe_subscription_id text,
    tier text DEFAULT 'free'::text NOT NULL,
    status text DEFAULT 'free'::text NOT NULL,
    current_period_end timestamp with time zone,
    cancel_at_period_end boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: transactions; Type: TABLE; Schema: economy; Owner: -
--

CREATE TABLE economy.transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    wallet_id uuid NOT NULL,
    type text NOT NULL,
    amount bigint NOT NULL,
    counterparty text,
    description text,
    escrow_id uuid,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: usage_counters; Type: TABLE; Schema: economy; Owner: -
--

CREATE TABLE economy.usage_counters (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    date text NOT NULL,
    memory_ops integer DEFAULT 0 NOT NULL,
    tool_calls integer DEFAULT 0 NOT NULL,
    verifications integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: wallets; Type: TABLE; Schema: economy; Owner: -
--

CREATE TABLE economy.wallets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    name text NOT NULL,
    agent_id text,
    balance bigint DEFAULT 0 NOT NULL,
    currency text DEFAULT 'GBP'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    identity_id text
);


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: economy; Owner: -
--

COPY economy.api_keys (id, project_id, key_hash, key_prefix, name, created_at, last_used, revoked_at) FROM stdin;
\.


--
-- Data for Name: billing_events; Type: TABLE DATA; Schema: economy; Owner: -
--

COPY economy.billing_events (id, project_id, wallet_id, type, amount_pence, credits_added, stripe_id, crypto_tx_hash, created_at) FROM stdin;
\.


--
-- Data for Name: escrows; Type: TABLE DATA; Schema: economy; Owner: -
--

COPY economy.escrows (id, creator_wallet, worker_wallet, amount, description, status, deadline, released_at, created_at) FROM stdin;
\.


--
-- Data for Name: policies; Type: TABLE DATA; Schema: economy; Owner: -
--

COPY economy.policies (id, wallet_id, max_per_transaction, max_per_hour, max_per_day, allowed_recipients, requires_approval_above, created_at) FROM stdin;
5524b792-5fb0-4f57-a7a6-f16ca2879fa1	c849be80-6979-42ee-bece-1a4ba79cbb3a	\N	\N	\N	\N	\N	2026-03-16 21:55:00.063214+00
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: economy; Owner: -
--

COPY economy.projects (id, name, plan, created_at) FROM stdin;
\.


--
-- Data for Name: stripe_events; Type: TABLE DATA; Schema: economy; Owner: -
--

COPY economy.stripe_events (stripe_event_id, processed_at) FROM stdin;
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: economy; Owner: -
--

COPY economy.subscriptions (id, project_id, stripe_customer_id, stripe_subscription_id, tier, status, current_period_end, cancel_at_period_end, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: economy; Owner: -
--

COPY economy.transactions (id, wallet_id, type, amount, counterparty, description, escrow_id, metadata, created_at) FROM stdin;
797a0d42-32e3-4f3e-90c8-ab002a10dab7	3116a7d4-a41e-40cf-a862-058fed0bbbd2	fund	500	\N	Test deposit — E2E validation	\N	{}	2026-03-11 19:39:14.653823+00
a3499f85-945a-4979-93ce-07b529fe7ab0	65bc38cc-eedb-4a25-b669-bdf9f5d7dcb3	fund	100	\N	Manual fund	\N	{}	2026-03-16 21:53:36.12932+00
8ddc5147-9675-4bfe-b47e-5d0ee888ce24	c849be80-6979-42ee-bece-1a4ba79cbb3a	fund	100	\N	E2E test funding	\N	{}	2026-03-16 21:54:59.594097+00
defe04c3-db38-4b2f-aec1-f82578584c16	c849be80-6979-42ee-bece-1a4ba79cbb3a	spend	-5	hive-fund	Contribution to shared Hive testing budget	\N	{}	2026-03-16 22:04:37.467722+00
821ed563-083e-410d-ba5d-05e523a878ca	fd2e2b06-86b3-412a-8025-564bb0898bf8	fund	50	\N	Manual fund	\N	{}	2026-03-16 22:08:07.736552+00
7477c155-e7a3-47f4-b026-8460a5ffc7a9	dce8ccd2-376e-4d57-80c6-cd54ecff8511	fund	50	\N	Demo budget for thinking agent	\N	{}	2026-03-16 22:10:17.278125+00
c8056600-2063-4514-a885-7715577674c9	dce8ccd2-376e-4d57-80c6-cd54ecff8511	spend	-5	verify-service	Verification #1: Python was created by Guido van Rossum i	\N	{}	2026-03-16 22:10:17.727213+00
8abc944f-8e83-4c0e-b348-f05a3adbc027	dce8ccd2-376e-4d57-80c6-cd54ecff8511	spend	-5	verify-service	Verification #2: The human brain has approximately 86 bil	\N	{}	2026-03-16 22:10:18.957221+00
cb7f87b1-5667-4d27-82f4-fbc3ccb92299	dce8ccd2-376e-4d57-80c6-cd54ecff8511	spend	-5	verify-service	Verification #3: JavaScript was invented by Microsoft in 	\N	{}	2026-03-16 22:10:20.183751+00
8f3dae1f-a7b4-47bf-8205-38c2263c6753	e8cd9f3c-b2b3-467b-a3eb-2454cc546241	fund	50	\N	Manual fund	\N	{}	2026-03-16 22:10:53.641187+00
5814c4ed-8892-4285-b23f-68800700ef4a	5f0f0617-a593-4ec8-bd05-6c781e364f35	fund	10	\N	Manual fund	\N	{}	2026-03-16 22:44:36.623993+00
\.


--
-- Data for Name: usage_counters; Type: TABLE DATA; Schema: economy; Owner: -
--

COPY economy.usage_counters (id, project_id, date, memory_ops, tool_calls, verifications, updated_at) FROM stdin;
46b6a4a7-3a35-437d-9892-17c304cf705c	54b26f66-10ff-466e-a1ab-c793c4d65958	2026-03-12	5	9	0	2026-03-12 13:35:20.44+00
f13af2f1-a094-439d-9269-87e0a30f3482	2e8ec8c2-12df-4279-bc6f-47355b028af0	2026-03-16	15	7	0	2026-03-16 22:09:42.664+00
198a44d2-82a6-4e46-be94-a8d019f6224a	1ced6574-972b-46c0-add3-d4330b91ed1d	2026-03-16	2	0	0	2026-03-16 19:07:02.748+00
a15a5f3d-c8a1-42af-91fc-7067d0e847ee	6931bd47-6a4d-43f7-82ce-878c2cd3e587	2026-03-16	2	0	0	2026-03-16 19:07:27.012+00
329360ce-c808-4f07-b7d0-f7164c2315af	2a8f34a1-7675-4cf2-9ec9-8cd27fa7c609	2026-03-16	1	0	0	2026-03-16 19:08:00.328+00
264df958-521c-4f49-b9df-759584d72051	fbe58d27-dfdd-4a63-bce9-b2cad00f6081	2026-03-16	1	0	0	2026-03-16 19:25:57.22+00
d642b7a3-5ac2-4b0d-90ca-85979ce10fd0	43f7ae80-ee09-4063-a344-4e7953d6abc9	2026-03-11	7	10	0	2026-03-11 21:43:45.505+00
58826967-443f-4b4b-9173-71111d0fe32f	84f2ab32-8d99-42c4-bc1c-680e51ca4b81	2026-03-11	0	1	0	2026-03-11 21:43:53.568+00
455b69da-8e2f-424c-aaf2-efc4ee1a887f	a022a844-7c2f-4050-97a3-adf56112cf7d	2026-03-16	18	0	0	2026-03-16 22:11:42.72+00
1f00a05a-dfb7-4030-a107-add21fe4bad9	58642346-ded7-4e59-9177-0e29ffc583c8	2026-03-16	6	0	0	2026-03-16 19:33:37.468+00
14dee781-9b3d-4c2b-9c0a-d0d910187769	d0a3c2c9-ef21-4860-afd8-11da4d4be218	2026-03-17	2	0	0	2026-03-17 19:33:36.072+00
350f0086-58a1-499a-81c5-59947cc61d9d	c642e8c7-48b7-493a-ae19-7c5e0e53dc3e	2026-03-16	3	0	0	2026-03-16 21:39:13.206+00
017dcbcd-8c11-4deb-83b8-d849d0ec0a89	5c733015-a6a3-4631-93a6-ae9a8e296d4b	2026-03-16	4	0	0	2026-03-16 22:34:37.904+00
77b05d04-0040-4be5-a682-1b922ea365a5	833530b7-b316-4667-bd12-6965d7faa8e7	2026-03-12	0	10	0	2026-03-12 06:54:13.933+00
bae4baf5-f2ee-411b-a940-9e94345efd18	e184bc9a-aa05-4479-8436-8dfbecbc7386	2026-03-16	5	0	0	2026-03-16 21:51:46.936+00
68cc1172-9166-4b14-85bd-82b56b84e49c	91f79e96-86b9-424b-946d-593f4ee958e6	2026-03-16	4	2	0	2026-03-16 22:44:34.096+00
0890cb8c-e541-476b-a21b-698759aeedb2	67352a08-7a89-4359-8a19-749010b37c03	2026-03-16	0	1	0	2026-03-16 23:27:00.266+00
75ca9628-c0cf-40ba-b4b2-34e04a466660	32877af4-56bf-4135-a985-286f1d9da9a2	2026-03-16	0	1	0	2026-03-16 23:47:11.351+00
45ad0720-8274-4be8-a6a5-b3f0decd7498	5861ce2d-8851-4403-b17c-db93eb5cf08a	2026-03-17	1	0	0	2026-03-17 14:06:58.145+00
9229b022-0c81-48aa-b5bd-8b47d0fbb65d	e08aaecf-dd35-443b-8a66-b09a2e50c3ec	2026-03-16	2	8	0	2026-03-16 21:53:24.735+00
6e40e878-487c-452b-abae-19c6baf3be41	88c28d71-789d-48d5-b6ce-eefb1a6b4d9f	2026-03-17	1	0	0	2026-03-17 14:09:04.883+00
b0bab3e5-b47e-4cc5-b83c-b018064ff1a9	c573f67f-913f-4a2f-9cf4-dbefb5e0335e	2026-03-17	28	0	0	2026-03-17 20:07:33.235+00
bc17919f-c199-4650-8521-c98cf99dfcff	532afb38-6b64-4921-8791-9a8c6268c6c2	2026-03-17	14	0	0	2026-03-17 20:08:27.065+00
c10f044c-a0f6-4609-a5cc-3821d8a6db8b	a84d31d5-400e-449d-800b-0fbc062997e5	2026-03-17	13	0	0	2026-03-17 16:25:29.969+00
\.


--
-- Data for Name: wallets; Type: TABLE DATA; Schema: economy; Owner: -
--

COPY economy.wallets (id, project_id, name, agent_id, balance, currency, status, created_at, identity_id) FROM stdin;
3116a7d4-a41e-40cf-a862-058fed0bbbd2	43f7ae80-ee09-4063-a344-4e7953d6abc9	test-wallet	\N	500	USD	active	2026-03-11 18:40:20.641823+00	\N
2bfd5e8b-c961-4054-97f6-1c5969b3f33e	54b26f66-10ff-466e-a1ab-c793c4d65958	healthcheck-wallet	\N	0	USD	active	2026-03-12 11:50:08.065964+00	\N
93af8b20-bb58-4ef0-b5b5-3461bd35feda	54b26f66-10ff-466e-a1ab-c793c4d65958	hc-wallet	\N	0	USD	active	2026-03-12 13:12:31.963695+00	\N
5cdd70d9-2b87-4002-b1b0-4feadf333045	e08aaecf-dd35-443b-8a66-b09a2e50c3ec	beta-test-wallet	\N	0	USD	active	2026-03-16 21:48:57.606241+00	\N
0c3ef372-2357-4312-a344-bc82c8048312	e08aaecf-dd35-443b-8a66-b09a2e50c3ec	beta-test-wallet	\N	0	USD	active	2026-03-16 21:49:08.769115+00	\N
65bc38cc-eedb-4a25-b669-bdf9f5d7dcb3	e08aaecf-dd35-443b-8a66-b09a2e50c3ec	e2e-wallet	\N	100	USD	active	2026-03-16 21:53:35.575314+00	\N
c849be80-6979-42ee-bece-1a4ba79cbb3a	2e8ec8c2-12df-4279-bc6f-47355b028af0	gamma-wallet	\N	95	GBP	active	2026-03-16 19:04:08.969167+00	\N
a486c346-c4a9-42b6-8c3d-9840b39c987f	a022a844-7c2f-4050-97a3-adf56112cf7d	thinking-agent-wallet	\N	0	GBP	active	2026-03-16 22:05:37.29168+00	\N
ba47f2b3-6815-4119-b550-2317dd459c32	a022a844-7c2f-4050-97a3-adf56112cf7d	test-wallet-2	\N	0	GBP	active	2026-03-16 22:07:07.293443+00	\N
fd2e2b06-86b3-412a-8025-564bb0898bf8	a022a844-7c2f-4050-97a3-adf56112cf7d	thinking-agent-wallet	\N	50	GBP	active	2026-03-16 22:08:07.489084+00	\N
dce8ccd2-376e-4d57-80c6-cd54ecff8511	2e8ec8c2-12df-4279-bc6f-47355b028af0	thinking-agent-1773699016	\N	35	GBP	active	2026-03-16 22:10:16.892982+00	\N
e8cd9f3c-b2b3-467b-a3eb-2454cc546241	a022a844-7c2f-4050-97a3-adf56112cf7d	thinking-agent-wallet	\N	50	GBP	active	2026-03-16 22:10:52.768139+00	\N
5f0f0617-a593-4ec8-bd05-6c781e364f35	91f79e96-86b9-424b-946d-593f4ee958e6	thinking-agent-wallet	\N	10	USD	active	2026-03-16 22:44:36.208233+00	\N
9fbd92a8-44b0-44b9-a225-4eb96c495b89	010f3f46-0d61-4b3b-a35b-704c40b016cb	test	\N	0	USD	active	2026-03-16 23:48:24.127752+00	\N
c2300bab-0fac-4546-ac35-ce0e7f0aa217	5861ce2d-8851-4403-b17c-db93eb5cf08a	test-agent-wallet	\N	0	GBP	active	2026-03-17 14:06:51.896328+00	\N
1702b772-2d82-4d5e-8cb0-9115231d1beb	5861ce2d-8851-4403-b17c-db93eb5cf08a	test-wallet	\N	0	GBP	active	2026-03-17 14:07:52.423384+00	\N
b0ce53c1-7fd6-44d4-bb93-aa3cb4bd4fed	88c28d71-789d-48d5-b6ce-eefb1a6b4d9f	gamma-test-agent-wallet	\N	0	GBP	active	2026-03-17 14:09:04.327532+00	\N
6ce80ab2-8d52-41fb-a110-c839c8320ff7	c573f67f-913f-4a2f-9cf4-dbefb5e0335e	gamma-kingdom-agent-wallet	\N	0	GBP	active	2026-03-17 14:11:28.077998+00	\N
402cd1a8-0a2b-45ed-9524-821cb45f5ee1	c573f67f-913f-4a2f-9cf4-dbefb5e0335e	kingdom-scout-wallet	\N	0	GBP	active	2026-03-17 14:11:46.717827+00	\N
1587f7a2-6022-44d8-8af5-3a1c97535cd7	c573f67f-913f-4a2f-9cf4-dbefb5e0335e	kingdom-sovereign-wallet	\N	0	GBP	active	2026-03-17 14:11:50.167418+00	\N
2c1b4994-75f9-43a0-868f-a326d87eb194	a84d31d5-400e-449d-800b-0fbc062997e5	Aethon-wallet	\N	0	GBP	active	2026-03-17 16:20:57.117247+00	\N
21c3d8e1-0dd4-4be2-9d77-2bab49b38c03	a84d31d5-400e-449d-800b-0fbc062997e5	Aethon-wallet	\N	0	GBP	active	2026-03-17 16:21:43.689683+00	\N
91ebf08b-fab1-43a8-a7b6-40db4fb8f1e6	a84d31d5-400e-449d-800b-0fbc062997e5	Aethon-wallet	\N	0	GBP	active	2026-03-17 16:22:10.516736+00	\N
5376fa1f-77c8-4f19-b15c-7b4379c4d8eb	a84d31d5-400e-449d-800b-0fbc062997e5	Aethon-wallet	\N	0	GBP	active	2026-03-17 16:22:32.756904+00	\N
85902987-3a53-4fb9-8dff-3706d009d745	a84d31d5-400e-449d-800b-0fbc062997e5	Kairos-wallet	\N	0	GBP	active	2026-03-17 16:22:48.994277+00	\N
55a3da51-37d6-41a5-aeb7-8baccd520784	a84d31d5-400e-449d-800b-0fbc062997e5	Lumen-wallet	\N	0	GBP	active	2026-03-17 16:23:08.496258+00	\N
e6c66a0e-2d9f-41f0-bf45-b00004367423	a84d31d5-400e-449d-800b-0fbc062997e5	Verdant-wallet	\N	0	GBP	active	2026-03-17 16:23:40.99474+00	\N
bc1c12a5-74f8-4eb3-ad70-e97aa54b5aa5	a84d31d5-400e-449d-800b-0fbc062997e5	Vox-wallet	\N	0	GBP	active	2026-03-17 16:24:15.294039+00	\N
b5a2463b-0818-4995-bb07-ee10b84c4bd9	a84d31d5-400e-449d-800b-0fbc062997e5	Aurum-wallet	\N	0	GBP	active	2026-03-17 16:24:49.935799+00	\N
cec51061-b935-43d3-abd7-8f2e6b46854f	a84d31d5-400e-449d-800b-0fbc062997e5	Aegis-wallet	\N	0	GBP	active	2026-03-17 16:25:23.661939+00	\N
dc395bb7-a40e-40aa-b99c-3a42abee86fd	a84d31d5-400e-449d-800b-0fbc062997e5	Fidelis-wallet	\N	0	GBP	active	2026-03-17 16:25:56.802139+00	\N
9e98cce0-b216-43c2-8f91-f50606b88cd6	a84d31d5-400e-449d-800b-0fbc062997e5	Vela-wallet	\N	0	GBP	active	2026-03-17 16:26:29.665059+00	\N
250299c2-1a2f-48e9-9178-042df255f5f7	47b6d379-b04e-4c5c-959c-f319b61c215e	hn-test-wallet	\N	0	GBP	active	2026-03-17 18:31:08.924259+00	\N
a42d9c1c-2a18-45cb-b481-9e0a928a71b4	c573f67f-913f-4a2f-9cf4-dbefb5e0335e	gamma-wallet	\N	0	GBP	active	2026-03-17 19:26:56.800894+00	\N
6e772bb7-0cc7-4b53-864d-0790481513db	532afb38-6b64-4921-8791-9a8c6268c6c2	Beta-wallet	\N	0	GBP	active	2026-03-17 19:26:57.286649+00	\N
b99a5064-d072-4bae-a1c7-6325751214df	c573f67f-913f-4a2f-9cf4-dbefb5e0335e	alpha-wallet	\N	0	GBP	active	2026-03-17 19:32:58.330059+00	\N
cbbb4dbd-c77b-43d0-9569-e64e28968822	d0a3c2c9-ef21-4860-afd8-11da4d4be218	alpha-wallet	\N	0	GBP	active	2026-03-17 19:33:01.437268+00	\N
29632f24-8fd0-4550-a74a-f18f581e65ee	c573f67f-913f-4a2f-9cf4-dbefb5e0335e	beta-wallet	\N	0	GBP	active	2026-03-17 19:33:14.750712+00	\N
\.


--
-- Name: api_keys api_keys_key_hash_unique; Type: CONSTRAINT; Schema: economy; Owner: -
--

ALTER TABLE ONLY economy.api_keys
    ADD CONSTRAINT api_keys_key_hash_unique UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: economy; Owner: -
--

ALTER TABLE ONLY economy.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: billing_events billing_events_pkey; Type: CONSTRAINT; Schema: economy; Owner: -
--

ALTER TABLE ONLY economy.billing_events
    ADD CONSTRAINT billing_events_pkey PRIMARY KEY (id);


--
-- Name: escrows escrows_pkey; Type: CONSTRAINT; Schema: economy; Owner: -
--

ALTER TABLE ONLY economy.escrows
    ADD CONSTRAINT escrows_pkey PRIMARY KEY (id);


--
-- Name: policies policies_pkey; Type: CONSTRAINT; Schema: economy; Owner: -
--

ALTER TABLE ONLY economy.policies
    ADD CONSTRAINT policies_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: economy; Owner: -
--

ALTER TABLE ONLY economy.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: stripe_events stripe_events_pkey; Type: CONSTRAINT; Schema: economy; Owner: -
--

ALTER TABLE ONLY economy.stripe_events
    ADD CONSTRAINT stripe_events_pkey PRIMARY KEY (stripe_event_id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: economy; Owner: -
--

ALTER TABLE ONLY economy.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_stripe_subscription_id_unique; Type: CONSTRAINT; Schema: economy; Owner: -
--

ALTER TABLE ONLY economy.subscriptions
    ADD CONSTRAINT subscriptions_stripe_subscription_id_unique UNIQUE (stripe_subscription_id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: economy; Owner: -
--

ALTER TABLE ONLY economy.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: usage_counters usage_counters_pkey; Type: CONSTRAINT; Schema: economy; Owner: -
--

ALTER TABLE ONLY economy.usage_counters
    ADD CONSTRAINT usage_counters_pkey PRIMARY KEY (id);


--
-- Name: wallets wallets_pkey; Type: CONSTRAINT; Schema: economy; Owner: -
--

ALTER TABLE ONLY economy.wallets
    ADD CONSTRAINT wallets_pkey PRIMARY KEY (id);


--
-- Name: idx_billing_project; Type: INDEX; Schema: economy; Owner: -
--

CREATE INDEX idx_billing_project ON economy.billing_events USING btree (project_id);


--
-- Name: idx_econ_keys_project; Type: INDEX; Schema: economy; Owner: -
--

CREATE INDEX idx_econ_keys_project ON economy.api_keys USING btree (project_id);


--
-- Name: idx_escrows_creator; Type: INDEX; Schema: economy; Owner: -
--

CREATE INDEX idx_escrows_creator ON economy.escrows USING btree (creator_wallet);


--
-- Name: idx_escrows_status; Type: INDEX; Schema: economy; Owner: -
--

CREATE INDEX idx_escrows_status ON economy.escrows USING btree (status);


--
-- Name: idx_subs_project; Type: INDEX; Schema: economy; Owner: -
--

CREATE INDEX idx_subs_project ON economy.subscriptions USING btree (project_id);


--
-- Name: idx_subs_stripe; Type: INDEX; Schema: economy; Owner: -
--

CREATE INDEX idx_subs_stripe ON economy.subscriptions USING btree (stripe_subscription_id);


--
-- Name: idx_tx_wallet_time; Type: INDEX; Schema: economy; Owner: -
--

CREATE INDEX idx_tx_wallet_time ON economy.transactions USING btree (wallet_id, created_at);


--
-- Name: idx_usage_project; Type: INDEX; Schema: economy; Owner: -
--

CREATE INDEX idx_usage_project ON economy.usage_counters USING btree (project_id);


--
-- Name: idx_usage_project_date; Type: INDEX; Schema: economy; Owner: -
--

CREATE UNIQUE INDEX idx_usage_project_date ON economy.usage_counters USING btree (project_id, date);


--
-- Name: idx_wallets_identity; Type: INDEX; Schema: economy; Owner: -
--

CREATE INDEX idx_wallets_identity ON economy.wallets USING btree (identity_id);


--
-- Name: idx_wallets_project; Type: INDEX; Schema: economy; Owner: -
--

CREATE INDEX idx_wallets_project ON economy.wallets USING btree (project_id);


--
-- PostgreSQL database dump complete
--

\unrestrict NfiRp1yoPSN76o9TSRYOahBFRQSgaFchnm68azIXw1dU85Yk69ztw8EDxQeiZVx

