--
-- PostgreSQL database dump
--

\restrict ShLBm0hisBDHcjPqJdkqFJdjsv9r8clbnIzx0LdD5Z81QZzTOga0rAotaEXb9Qv

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.9 (Ubuntu 17.9-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: verify; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA verify;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: api_keys; Type: TABLE; Schema: verify; Owner: -
--

CREATE TABLE verify.api_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    key_hash text NOT NULL,
    key_prefix text NOT NULL,
    name text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used timestamp with time zone,
    revoked_at timestamp with time zone
);


--
-- Name: billing_events; Type: TABLE; Schema: verify; Owner: -
--

CREATE TABLE verify.billing_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    type text NOT NULL,
    amount_pence integer DEFAULT 0 NOT NULL,
    credits_added bigint DEFAULT 0 NOT NULL,
    stripe_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: projects; Type: TABLE; Schema: verify; Owner: -
--

CREATE TABLE verify.projects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    plan text DEFAULT 'dev'::text NOT NULL,
    credits integer DEFAULT 50 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: usage_events; Type: TABLE; Schema: verify; Owner: -
--

CREATE TABLE verify.usage_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    operation text NOT NULL,
    credits_used integer NOT NULL,
    duration_ms integer,
    success boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: verification_cache; Type: TABLE; Schema: verify; Owner: -
--

CREATE TABLE verify.verification_cache (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    claim_hash text NOT NULL,
    domain text,
    verdict text NOT NULL,
    confidence real NOT NULL,
    evidence_json jsonb NOT NULL,
    sources_json jsonb NOT NULL,
    llm_model text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


--
-- Name: verified_facts; Type: TABLE; Schema: verify; Owner: -
--

CREATE TABLE verify.verified_facts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    assertion text NOT NULL,
    domain text,
    confidence real NOT NULL,
    source_count integer NOT NULL,
    last_verified timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: verify; Owner: -
--

COPY verify.api_keys (id, project_id, key_hash, key_prefix, name, created_at, last_used, revoked_at) FROM stdin;
\.


--
-- Data for Name: billing_events; Type: TABLE DATA; Schema: verify; Owner: -
--

COPY verify.billing_events (id, project_id, type, amount_pence, credits_added, stripe_id, created_at) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: verify; Owner: -
--

COPY verify.projects (id, name, plan, credits, created_at) FROM stdin;
\.


--
-- Data for Name: usage_events; Type: TABLE DATA; Schema: verify; Owner: -
--

COPY verify.usage_events (id, project_id, operation, credits_used, duration_ms, success, created_at) FROM stdin;
\.


--
-- Data for Name: verification_cache; Type: TABLE DATA; Schema: verify; Owner: -
--

COPY verify.verification_cache (id, claim_hash, domain, verdict, confidence, evidence_json, sources_json, llm_model, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: verified_facts; Type: TABLE DATA; Schema: verify; Owner: -
--

COPY verify.verified_facts (id, assertion, domain, confidence, source_count, last_verified, created_at) FROM stdin;
\.


--
-- Name: api_keys api_keys_key_hash_unique; Type: CONSTRAINT; Schema: verify; Owner: -
--

ALTER TABLE ONLY verify.api_keys
    ADD CONSTRAINT api_keys_key_hash_unique UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: verify; Owner: -
--

ALTER TABLE ONLY verify.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: billing_events billing_events_pkey; Type: CONSTRAINT; Schema: verify; Owner: -
--

ALTER TABLE ONLY verify.billing_events
    ADD CONSTRAINT billing_events_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: verify; Owner: -
--

ALTER TABLE ONLY verify.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: usage_events usage_events_pkey; Type: CONSTRAINT; Schema: verify; Owner: -
--

ALTER TABLE ONLY verify.usage_events
    ADD CONSTRAINT usage_events_pkey PRIMARY KEY (id);


--
-- Name: verification_cache verification_cache_pkey; Type: CONSTRAINT; Schema: verify; Owner: -
--

ALTER TABLE ONLY verify.verification_cache
    ADD CONSTRAINT verification_cache_pkey PRIMARY KEY (id);


--
-- Name: verified_facts verified_facts_pkey; Type: CONSTRAINT; Schema: verify; Owner: -
--

ALTER TABLE ONLY verify.verified_facts
    ADD CONSTRAINT verified_facts_pkey PRIMARY KEY (id);


--
-- Name: idx_api_keys_project; Type: INDEX; Schema: verify; Owner: -
--

CREATE INDEX idx_api_keys_project ON verify.api_keys USING btree (project_id);


--
-- Name: idx_usage_time; Type: INDEX; Schema: verify; Owner: -
--

CREATE INDEX idx_usage_time ON verify.usage_events USING btree (project_id, created_at);


--
-- Name: idx_vcache_expires; Type: INDEX; Schema: verify; Owner: -
--

CREATE INDEX idx_vcache_expires ON verify.verification_cache USING btree (expires_at);


--
-- Name: idx_vcache_hash; Type: INDEX; Schema: verify; Owner: -
--

CREATE INDEX idx_vcache_hash ON verify.verification_cache USING btree (claim_hash);


--
-- Name: idx_verify_billing_project; Type: INDEX; Schema: verify; Owner: -
--

CREATE INDEX idx_verify_billing_project ON verify.billing_events USING btree (project_id);


--
-- PostgreSQL database dump complete
--

\unrestrict ShLBm0hisBDHcjPqJdkqFJdjsv9r8clbnIzx0LdD5Z81QZzTOga0rAotaEXb9Qv

